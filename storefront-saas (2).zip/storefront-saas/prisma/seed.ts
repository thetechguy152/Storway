import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/server/security";
import { provisionStore } from "../src/modules/tenancy/service";

const prisma = new PrismaClient();

async function main() {
  const email = "demo@example.com";
  const user =
    (await prisma.user.findUnique({ where: { email } })) ??
    (await prisma.user.create({
      data: {
        email,
        name: "Demo Merchant",
        passwordHash: await hashPassword("demo-password-123"),
        verifiedAt: new Date(),
      },
    }));

  if (await prisma.store.findUnique({ where: { slug: "demo" } })) return console.log("seed: already done");

  const store = await provisionStore(user.id, { name: "Demo Store", slug: "demo", currency: "USD", timezone: "UTC" });
  const product = await prisma.product.create({
    data: {
      storeId: store.id,
      title: "Everyday Tote",
      slug: "everyday-tote",
      description: "A sturdy canvas tote.",
      status: "PUBLISHED",
      publishedAt: new Date(),
    },
  });
  await prisma.variant.create({
    data: { storeId: store.id, productId: product.id, sku: "TOTE-NAT", options: { Color: "Natural" }, priceMinor: 2400, currency: "USD" },
  });
  console.log("seed: demo@example.com / demo-password-123 -> http://demo.localhost:3000");
}

main().finally(() => prisma.$disconnect());
