import { describe, it, expect, beforeAll } from "vitest";
import { prisma } from "@/server/db";
import { forStore } from "@/server/tenant-db";

// Needs a migrated database: DATABASE_URL must be set.
describe.skipIf(!process.env.DATABASE_URL)("tenant isolation", () => {
  let storeA = "", storeB = "", productB = "";

  beforeAll(async () => {
    const user = await prisma.user.create({
      data: { email: `iso-${Date.now()}@test.dev`, passwordHash: "x" },
    });
    const org = await prisma.organization.create({ data: { ownerUserId: user.id, name: "Iso" } });
    const mk = (n: string) =>
      prisma.store.create({ data: { organizationId: org.id, name: n, slug: `${n}-${Date.now()}` } });
    storeA = (await mk("iso-a")).id;
    storeB = (await mk("iso-b")).id;
    productB = (await prisma.product.create({ data: { storeId: storeB, title: "Secret", slug: "secret" } })).id;
  });

  it("A cannot read B's product", async () => {
    expect(await forStore(storeA).product.findFirst({ where: { id: productB } })).toBeNull();
  });

  it("A cannot update or delete B's product", async () => {
    const u = await forStore(storeA).product.updateMany({ where: { id: productB }, data: { title: "hacked" } });
    const d = await forStore(storeA).product.deleteMany({ where: { id: productB } });
    expect(u.count + d.count).toBe(0);
  });

  it("lists contain only the caller's store", async () => {
    await forStore(storeA).product.create({ data: { title: "Mine", slug: "mine" } as never });
    const list = await forStore(storeA).product.findMany();
    expect(list.length).toBeGreaterThan(0);
    expect(list.every((p) => p.storeId === storeA)).toBe(true);
  });

  it("a client-supplied storeId on create is overridden", async () => {
    const p = await forStore(storeA).product.create({
      data: { title: "x", slug: "x", storeId: storeB } as never,
    });
    expect(p.storeId).toBe(storeA);
  });

  it("DB rejects a variant whose product belongs to another store", async () => {
    await expect(
      prisma.variant.create({
        data: { storeId: storeA, productId: productB, priceMinor: 1, currency: "USD" },
      })
    ).rejects.toThrow();
  });
});

describe.skipIf(!process.env.DATABASE_URL)("theme isolation", () => {
  it("store A cannot read or modify store B's theme", async () => {
    const user = await prisma.user.create({ data: { email: `th-${Date.now()}@test.dev`, passwordHash: "x" } });
    const org = await prisma.organization.create({ data: { ownerUserId: user.id, name: "T" } });
    const a = await prisma.store.create({ data: { organizationId: org.id, name: "a", slug: `tha-${Date.now()}` } });
    const b = await prisma.store.create({ data: { organizationId: org.id, name: "b", slug: `thb-${Date.now()}` } });
    await prisma.storeTheme.create({ data: { storeId: b.id, baseThemeId: "bold", draftTokens: {} } });

    expect(await forStore(a.id).storeTheme.findFirst()).toBeNull();
    const r = await forStore(a.id).storeTheme.updateMany({ where: {}, data: { baseThemeId: "hacked" } });
    expect(r.count).toBe(0);
    expect((await prisma.storeTheme.findUniqueOrThrow({ where: { storeId: b.id } })).baseThemeId).toBe("bold");
  });
});
