import { describe, it, expect } from "vitest";
import { hasPermission, DEFAULT_ROLES } from "@/modules/tenancy/rbac";
import { slugSchema } from "@/modules/tenancy/schemas";
import { slugify } from "@/server/slug";

describe("rbac", () => {
  it("owner has everything, staff cannot write catalog", () => {
    expect(hasPermission(DEFAULT_ROLES.owner!, "anything")).toBe(true);
    expect(hasPermission(DEFAULT_ROLES.staff!, "catalog:write")).toBe(false);
    expect(hasPermission(DEFAULT_ROLES.staff!, "catalog:read")).toBe(true);
  });
});

describe("slugs", () => {
  it("slugify strips accents and symbols", () => {
    expect(slugify("Café Déjà Vu!")).toBe("cafe-deja-vu");
  });
  it("rejects reserved and malformed store slugs", () => {
    expect(slugSchema.safeParse("admin").success).toBe(false);
    expect(slugSchema.safeParse("-bad-").success).toBe(false);
    expect(slugSchema.safeParse("acme-shop").success).toBe(true);
  });
});
