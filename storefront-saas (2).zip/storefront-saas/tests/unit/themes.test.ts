import { describe, it, expect } from "vitest";
import { BASE_THEMES, PRESETS, STARTERS } from "@/themes/catalog";
import { sectionsSchema, tokensSchema, pageSlugSchema } from "@/themes/schema";
import { signPreview, verifyPreview } from "@/modules/theme/preview";

describe("theme catalog", () => {
  it("every base theme, preset and starter is valid", () => {
    for (const t of BASE_THEMES) expect(tokensSchema.safeParse(t.defaultTokens).success).toBe(true);
    for (const p of PRESETS) {
      expect(tokensSchema.safeParse(p.tokens).success).toBe(true);
      expect(sectionsSchema.safeParse(p.home).success).toBe(true);
      expect(BASE_THEMES.some((t) => t.id === p.baseThemeId)).toBe(true);
    }
    for (const s of STARTERS) expect(sectionsSchema.safeParse(s.sections).success).toBe(true);
  });
  it("preset and starter ids are unique", () => {
    expect(new Set(PRESETS.map((p) => p.id)).size).toBe(PRESETS.length);
    expect(new Set(STARTERS.map((s) => s.id)).size).toBe(STARTERS.length);
  });
});

describe("theme input is locked down", () => {
  const good = PRESETS[0]!.tokens;
  it("rejects CSS injection via colors and unknown fonts", () => {
    expect(tokensSchema.safeParse({ ...good, colors: { ...good.colors, primary: "red;} body{display:none" } }).success).toBe(false);
    expect(tokensSchema.safeParse({ ...good, fonts: { heading: "Comic Sans; x", body: "system" } }).success).toBe(false);
  });
  it("rejects javascript: links and unknown section types", () => {
    const hero = (ctaHref: string) => [{ id: "a", type: "hero", settings: { heading: "x", ctaLabel: "y", ctaHref } }];
    expect(sectionsSchema.safeParse(hero("javascript:alert(1)")).success).toBe(false);
    expect(sectionsSchema.safeParse(hero("/products")).success).toBe(true);
    expect(sectionsSchema.safeParse([{ id: "a", type: "script", settings: {} }]).success).toBe(false);
  });
  it("page slugs are url-safe", () => {
    expect(pageSlugSchema.safeParse("about-us").success).toBe(true);
    expect(pageSlugSchema.safeParse("../etc").success).toBe(false);
  });
});

describe("preview tokens", () => {
  it("round-trips, rejects tampering and expiry", () => {
    const t = signPreview("store-1");
    expect(verifyPreview(t)).toEqual({ storeId: "store-1" });
    expect(verifyPreview(t.replace("store-1", "store-2"))).toBeNull();
    expect(verifyPreview(signPreview("store-1", -10))).toBeNull();
    expect(verifyPreview(undefined)).toBeNull();
  });
});

import { sniffImage } from "@/server/media";
import { googleFontsHref, collectImageIds, FONTS } from "@/themes/schema";

describe("google fonts", () => {
  const base = PRESETS[0]!.tokens;
  it("builds a URL only from allowlisted fonts", () => {
    expect(googleFontsHref(base)).toBeNull(); // serif + system need no download
    const href = googleFontsHref({ ...base, fonts: { heading: "playfair", body: "inter" } })!;
    expect(href).toContain("family=Playfair+Display:wght@400;600;700");
    expect(href).toContain("family=Inter:wght@400;600;700");
    expect(href.startsWith("https://fonts.googleapis.com/css2?")).toBe(true);
  });
  it("every font entry is well formed", () => {
    for (const f of Object.values(FONTS)) expect(f.stack.length).toBeGreaterThan(0);
  });
});

describe("images", () => {
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(8)]);
  it("detects real images by magic bytes", () => {
    expect(sniffImage(png)?.mime).toBe("image/png");
    expect(sniffImage(Buffer.from([0xff, 0xd8, 0xff, 0xe0]))?.mime).toBe("image/jpeg");
  });
  it("rejects SVG, HTML and text pretending to be images", () => {
    expect(sniffImage(Buffer.from("<svg xmlns='http://www.w3.org/2000/svg'><script/></svg>"))).toBeNull();
    expect(sniffImage(Buffer.from("<html><script>alert(1)</script>"))).toBeNull();
  });
  it("collects image ids from sections and requires uuids", () => {
    const id = "123e4567-e89b-42d3-a456-426614174000";
    const sections = [
      { id: "a", type: "hero" as const, settings: { heading: "x", align: "center" as const, imageId: id } },
      { id: "b", type: "imageText" as const, settings: { body: "y", imageAlt: "", imagePosition: "left" as const, imageId: id } },
    ];
    expect(collectImageIds(sections)).toEqual([id]);
    expect(sectionsSchema.safeParse([{ id: "a", type: "hero", settings: { heading: "x", imageId: "http://evil/x.png" } }]).success).toBe(false);
  });
});
