import { describe, it, expect } from "vitest";
import { hashPassword, verifyPassword, newToken, sha256 } from "@/server/security";

describe("passwords", () => {
  it("verifies the right password and rejects the wrong one", async () => {
    const h = await hashPassword("correct horse battery");
    expect(await verifyPassword("correct horse battery", h)).toBe(true);
    expect(await verifyPassword("wrong", h)).toBe(false);
  });
  it("salts every hash", async () => {
    expect(await hashPassword("same")).not.toBe(await hashPassword("same"));
  });
});

describe("tokens", () => {
  it("stores only a hash of the token", () => {
    const { token, hash } = newToken();
    expect(hash).toBe(sha256(token));
    expect(hash).not.toContain(token);
  });
});
