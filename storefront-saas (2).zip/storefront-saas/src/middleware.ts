import { NextRequest, NextResponse } from "next/server";

/**
 * One deployment serves the platform AND every storefront.
 *   platform host (ROOT_DOMAIN)         -> admin app, /api, /login ...
 *   <slug>.ROOT_DOMAIN                  -> /sites/s~<slug>/...
 *   any other host (custom domain)      -> /sites/d~<host>/...  (verified in the page)
 * No DB access here (edge runtime); the page resolves and validates the tenant.
 */
export function middleware(req: NextRequest) {
  const root = (process.env.ROOT_DOMAIN ?? "localhost:3000").split(":")[0]!.toLowerCase();
  const host = (req.headers.get("host") ?? "").split(":")[0]!.toLowerCase();
  const { pathname } = req.nextUrl;

  if (host === root || host === `www.${root}`) {
    // The internal tenant route tree must not be reachable from the platform host.
    if (pathname.startsWith("/sites")) return NextResponse.rewrite(new URL("/404", req.url));
    return NextResponse.next();
  }

  // Storefront hosts don't serve the platform's own app routes.
  if (pathname.startsWith("/api") || pathname.startsWith("/admin")) return NextResponse.next();

  const key = host.endsWith(`.${root}`) ? `s~${host.slice(0, -(root.length + 1))}` : `d~${host}`;
  const url = req.nextUrl.clone();
  url.pathname = `/sites/${encodeURIComponent(key)}${pathname === "/" ? "" : pathname}`;
  return NextResponse.rewrite(url);
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
