import { z } from "zod";
import { slugSchema } from "@/modules/tenancy/schemas";

export const variantInput = z.object({
  sku: z.string().trim().min(1).max(64).optional(),
  options: z.record(z.string().min(1).max(50), z.string().min(1).max(100)).default({}),
  priceMinor: z.number().int().min(0).max(1_000_000_000),
  currency: z.string().length(3).transform((s) => s.toUpperCase()),
  active: z.boolean().default(true),
});

const seo = z
  .object({ title: z.string().max(70).optional(), description: z.string().max(160).optional() })
  .optional();

export const createProductInput = z.object({
  title: z.string().trim().min(1).max(200),
  slug: slugSchema.optional(),
  description: z.string().max(10_000).optional(),
  seo,
  variants: z.array(variantInput).min(1).max(100),
});

export const updateProductInput = z
  .object({
    title: z.string().trim().min(1).max(200),
    description: z.string().max(10_000).nullable(),
    seo,
  })
  .partial();

export const listProductsQuery = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(25),
  cursor: z.string().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).optional(),
});

export type CreateProductInput = z.infer<typeof createProductInput>;
export type UpdateProductInput = z.infer<typeof updateProductInput>;
