import { randomBytes } from "crypto";
import { Prisma } from "@prisma/client";
import { prisma } from "@/server/db";
import { AppError, notFound } from "@/server/errors";
import { slugify } from "@/server/slug";
import { audit } from "@/modules/audit/service";
import type { StoreContext } from "@/modules/tenancy/context";
import type { CreateProductInput, UpdateProductInput } from "./schemas";

const withVariants = { variants: { orderBy: { id: "asc" as const } } };

async function uniqueSlug(ctx: StoreContext, base: string) {
  const taken = await ctx.db.product.findFirst({ where: { slug: base }, select: { id: true } });
  return taken ? `${base}-${randomBytes(2).toString("hex")}` : base;
}

export async function createProduct(ctx: StoreContext, input: CreateProductInput) {
  ctx.require("catalog:write");
  const slug = await uniqueSlug(ctx, input.slug ?? (slugify(input.title) || "product"));
  const { storeId } = ctx;

  // Interactive transaction on the raw client, so storeId is passed explicitly
  // on every write. Reads outside of transactions go through ctx.db.
  const product = await prisma.$transaction(async (tx) => {
    const p = await tx.product.create({
      data: {
        storeId,
        title: input.title,
        slug,
        description: input.description,
        seo: input.seo as Prisma.InputJsonValue | undefined,
      },
    });
    await tx.variant.createMany({
      data: input.variants.map((v) => ({
        storeId,
        productId: p.id,
        sku: v.sku,
        options: v.options,
        priceMinor: v.priceMinor,
        currency: v.currency,
        active: v.active,
      })),
    });
    return tx.product.findFirstOrThrow({ where: { id: p.id, storeId }, include: withVariants });
  });

  await audit({ storeId, actorId: ctx.userId, action: "product.created", target: product.id });
  return product;
}

export async function listProducts(
  ctx: StoreContext,
  q: { limit: number; cursor?: string; status?: "DRAFT" | "PUBLISHED" | "ARCHIVED" }
) {
  ctx.require("catalog:read");
  const rows = await ctx.db.product.findMany({
    where: q.status ? { status: q.status } : {},
    include: withVariants,
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: q.limit + 1,
    ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
  });
  const hasMore = rows.length > q.limit;
  const items = hasMore ? rows.slice(0, q.limit) : rows;
  return { items, nextCursor: hasMore ? items[items.length - 1]!.id : null };
}

export async function getProduct(ctx: StoreContext, productId: string) {
  ctx.require("catalog:read");
  const product = await ctx.db.product.findFirst({ where: { id: productId }, include: withVariants });
  if (!product) throw notFound("Product");
  return product;
}

export async function updateProduct(ctx: StoreContext, productId: string, input: UpdateProductInput) {
  ctx.require("catalog:write");
  await getProduct(ctx, productId);
  const product = await ctx.db.product.update({
    where: { id: productId },
    data: {
      title: input.title,
      description: input.description,
      seo: input.seo as Prisma.InputJsonValue | undefined,
    },
    include: withVariants,
  });
  await audit({ storeId: ctx.storeId, actorId: ctx.userId, action: "product.updated", target: productId });
  return product;
}

export async function publishProduct(ctx: StoreContext, productId: string) {
  ctx.require("catalog:write");
  const product = await getProduct(ctx, productId);

  const errors: string[] = [];
  if (!product.title.trim()) errors.push("Title is required");
  if (!product.variants.some((v) => v.active)) errors.push("At least one active variant is required");
  if (errors.length)
    throw new AppError(422, "not_publishable", "Product is incomplete", { publish: errors });

  const published = await ctx.db.product.update({
    where: { id: productId },
    data: { status: "PUBLISHED", publishedAt: product.publishedAt ?? new Date() },
    include: withVariants,
  });
  await audit({ storeId: ctx.storeId, actorId: ctx.userId, action: "product.published", target: productId });
  // Later: emit "product.published" so the worker can reindex search / purge caches.
  return published;
}
