import { prisma } from "@/server/db";

export async function audit(entry: {
  storeId?: string;
  actorId: string;
  action: string; // e.g. "product.published"
  target?: string;
  metadata?: object;
}) {
  await prisma.auditLog.create({ data: entry });
}
