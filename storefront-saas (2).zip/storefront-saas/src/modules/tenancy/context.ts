import { NextRequest } from "next/server";
import { prisma } from "@/server/db";
import { forStore, TenantDb } from "@/server/tenant-db";
import { forbidden, notFound } from "@/server/errors";
import { authenticate } from "@/modules/auth/session";
import { hasPermission } from "./rbac";

export type StoreContext = {
  userId: string;
  storeId: string;
  permissions: string[];
  db: TenantDb;
  can: (permission: string) => boolean;
  require: (permission: string) => void;
};

/**
 * The ONLY way a merchant API route gets a store. The storeId in the URL is
 * a candidate: it is honored only if the signed-in user has an ACTIVE
 * membership in that ACTIVE store. Non-members get the same 404 as a missing
 * store, so store ids can't be probed.
 */
export async function requireStoreContext(req: NextRequest, storeId: string): Promise<StoreContext> {
  const user = await authenticate(req);
  return buildStoreContext(user.id, storeId);
}

/** Same checks, for server components that already know the user (cookie session). */
export async function buildStoreContext(userId: string, storeId: string): Promise<StoreContext> {
  const m = await prisma.membership.findUnique({
    where: { userId_storeId: { userId, storeId } },
    include: { role: true, store: { select: { status: true } } },
  });
  if (!m || m.status !== "ACTIVE" || m.store.status !== "ACTIVE") throw notFound("Store");

  const permissions = m.role.permissions;
  const can = (p: string) => hasPermission(permissions, p);
  return {
    userId,
    storeId,
    permissions,
    db: forStore(storeId),
    can,
    require: (p) => {
      if (!can(p)) throw forbidden(`Missing permission: ${p}`);
    },
  };
}
