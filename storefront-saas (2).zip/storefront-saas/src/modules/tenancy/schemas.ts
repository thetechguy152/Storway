import { z } from "zod";

const RESERVED = new Set([
  "www", "api", "admin", "app", "mail", "static", "assets", "cdn", "dashboard",
  "login", "signup", "support", "status", "docs", "blog", "help", "billing",
]);

export const slugSchema = z
  .string()
  .trim()
  .toLowerCase()
  .regex(/^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])$/, "3-30 chars: letters, numbers, hyphens")
  .refine((s) => !RESERVED.has(s), "This name is reserved");

export const createStoreInput = z.object({
  name: z.string().trim().min(2).max(80),
  slug: slugSchema,
  currency: z.string().length(3).transform((s) => s.toUpperCase()).default("USD"),
  timezone: z.string().min(1).max(64).default("UTC"),
});
