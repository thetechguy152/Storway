import { prisma, isUniqueViolation, toJson } from "@/server/db";
import { AppError } from "@/server/errors";
import { DEFAULT_ROLES } from "./rbac";
import { DEFAULT_PRESET_ID, getPreset } from "@/themes/catalog";

export async function provisionStore(
  userId: string,
  input: { name: string; slug: string; currency: string; timezone: string }
) {
  try {
    return await prisma.$transaction(async (tx) => {
      const org =
        (await tx.organization.findFirst({ where: { ownerUserId: userId } })) ??
        (await tx.organization.create({ data: { ownerUserId: userId, name: input.name } }));

      const store = await tx.store.create({
        data: {
          organizationId: org.id,
          name: input.name,
          slug: input.slug,
          currency: input.currency,
          timezone: input.timezone,
        },
      });

      let ownerRoleId = "";
      for (const [name, permissions] of Object.entries(DEFAULT_ROLES)) {
        const role = await tx.role.create({ data: { storeId: store.id, name, permissions } });
        if (name === "owner") ownerRoleId = role.id;
      }
      await tx.membership.create({ data: { userId, storeId: store.id, roleId: ownerRoleId } });
      // New stores launch with a published default theme and home page.
      const preset = getPreset(DEFAULT_PRESET_ID)!;
      await tx.storeTheme.create({
        data: {
          storeId: store.id,
          baseThemeId: preset.baseThemeId,
          presetId: preset.id,
          draftTokens: toJson(preset.tokens),
          publishedBaseThemeId: preset.baseThemeId,
          publishedTokens: toJson(preset.tokens),
          publishedAt: new Date(),
        },
      });
      await tx.page.create({
        data: { storeId: store.id, slug: "home", title: "Home", draft: toJson(preset.home), published: toJson(preset.home) },
      });
      await tx.auditLog.create({
        data: { storeId: store.id, actorId: userId, action: "store.provisioned", target: store.id },
      });
      return store;
    });
  } catch (e) {
    if (isUniqueViolation(e, "slug")) throw new AppError(409, "slug_taken", "That store address is taken");
    throw e;
  }
}

export function listStoresForUser(userId: string) {
  return prisma.store.findMany({
    where: { memberships: { some: { userId, status: "ACTIVE" } } },
    select: { id: true, name: true, slug: true, currency: true, status: true },
    orderBy: { createdAt: "asc" },
  });
}
