import { prisma } from "@/server/db";

/**
 * Tenant keys are produced by src/middleware.ts:
 *   "s~<slug>"      store subdomain  (acme.platform.com)
 *   "d~<hostname>"  custom domain    (shop.acme.com), only when VERIFIED
 */
export async function resolveTenant(key: string) {
  const kind = key.slice(0, 2);
  const value = key.slice(2).toLowerCase();
  const select = { id: true, name: true, slug: true, currency: true, status: true } as const;

  let store = null;
  if (kind === "s~") {
    store = await prisma.store.findUnique({ where: { slug: value }, select });
  } else if (kind === "d~") {
    const domain = await prisma.domain.findUnique({
      where: { hostname: value },
      include: { store: { select } },
    });
    store = domain?.status === "VERIFIED" ? domain.store : null;
  }
  return store && store.status === "ACTIVE" ? store : null;
}
