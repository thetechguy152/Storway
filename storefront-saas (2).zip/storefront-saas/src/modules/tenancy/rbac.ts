export const PERMISSIONS = [
  "catalog:read",
  "catalog:write",
  "orders:read",
  "orders:write",
  "customers:read",
  "customers:write",
  "media:read",
  "media:write",
  "theme:read",
  "theme:write",
  "media:read",
  "media:write",
  "settings:write",
  "staff:manage",
] as const;

export type Permission = (typeof PERMISSIONS)[number];

/** Roles created for every new store. "*" means everything. */
export const DEFAULT_ROLES: Record<string, string[]> = {
  owner: ["*"],
  admin: [...PERMISSIONS].filter((p) => p !== "staff:manage"),
  staff: ["catalog:read", "orders:read", "customers:read"],
};

export function hasPermission(granted: string[], required: string): boolean {
  return granted.includes("*") || granted.includes(required);
}
