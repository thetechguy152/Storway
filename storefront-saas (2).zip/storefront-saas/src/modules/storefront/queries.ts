import { forStore } from "@/server/tenant-db";

/** Public read model: only published products and only customer-safe fields. */
const publicSelect = {
  id: true,
  title: true,
  slug: true,
  description: true,
  seo: true,
  variants: {
    where: { active: true },
    select: { id: true, options: true, priceMinor: true, currency: true },
    orderBy: { priceMinor: "asc" as const },
  },
};

export function listPublishedProducts(storeId: string, limit = 48) {
  return forStore(storeId).product.findMany({
    where: { status: "PUBLISHED" },
    select: publicSelect,
    orderBy: { publishedAt: "desc" },
    take: limit,
  });
}

export function getPublishedProduct(storeId: string, slug: string) {
  return forStore(storeId).product.findFirst({
    where: { slug, status: "PUBLISHED" },
    select: publicSelect,
  });
}
