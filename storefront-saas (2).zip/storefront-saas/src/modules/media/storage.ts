import { mkdir, readFile, unlink, writeFile } from "fs/promises";
import path from "path";
import { env } from "@/config/env";

/** Three methods. Implement them over S3/R2/GCS for production (container disks are ephemeral). */
export interface StorageDriver {
  put(key: string, data: Buffer): Promise<void>;
  get(key: string): Promise<Buffer>;
  delete(key: string): Promise<void>;
}

class LocalStorage implements StorageDriver {
  private root = path.resolve(env().UPLOAD_DIR);

  private full(key: string) {
    const p = path.resolve(this.root, key);
    if (!p.startsWith(this.root + path.sep)) throw new Error("Invalid storage key");
    return p;
  }
  async put(key: string, data: Buffer) {
    const file = this.full(key);
    await mkdir(path.dirname(file), { recursive: true });
    await writeFile(file, data);
  }
  get(key: string) {
    return readFile(this.full(key));
  }
  delete(key: string) {
    return unlink(this.full(key));
  }
}

let driver: StorageDriver | undefined;
export const getStorage = () => (driver ??= new LocalStorage());
