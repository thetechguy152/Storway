import { randomUUID } from "crypto";
import { env } from "@/config/env";
import { AppError } from "@/server/errors";
import { sniffImage } from "@/server/media";
import { storage } from "@/server/storage";
import { audit } from "@/modules/audit/service";
import type { StoreContext } from "@/modules/tenancy/context";

const MAX_ASSETS_PER_STORE = 500;

export async function uploadImage(ctx: StoreContext, file: File) {
  ctx.require("media:write");
  const maxBytes = env().MAX_UPLOAD_MB * 1024 * 1024;
  if (file.size === 0) throw new AppError(400, "empty_file", "File is empty");
  if (file.size > maxBytes) throw new AppError(413, "file_too_large", `Max ${env().MAX_UPLOAD_MB} MB`);
  if ((await ctx.db.mediaAsset.count()) >= MAX_ASSETS_PER_STORE)
    throw new AppError(422, "media_limit", "Media library is full");

  const data = Buffer.from(await file.arrayBuffer());
  const kind = sniffImage(data);
  if (!kind) throw new AppError(415, "unsupported_type", "Only PNG, JPEG, GIF and WebP images are allowed");

  const id = randomUUID();
  const key = `${ctx.storeId}/${id}.${kind.ext}`; // server-generated: user input never reaches the path
  await storage.put(key, data);

  const asset = await ctx.db.mediaAsset.create({
    data: {
      id,
      storeId: ctx.storeId,
      key,
      mime: kind.mime,
      sizeBytes: data.length,
      filename: file.name.replace(/[^\w.\- ]+/g, "_").slice(0, 120) || "image",
    },
  });
  await audit({ storeId: ctx.storeId, actorId: ctx.userId, action: "media.uploaded", target: id });
  return toDto(asset);
}

export async function listMedia(ctx: StoreContext) {
  ctx.require("media:read");
  const rows = await ctx.db.mediaAsset.findMany({ orderBy: { createdAt: "desc" }, take: 200 });
  return rows.map(toDto);
}

/**
 * Sections reference images by id. Without this check a merchant could embed
 * ANOTHER store's asset id (ids are public in storefront HTML).
 */
export async function assertAssetsOwned(ctx: StoreContext, ids: string[]) {
  if (ids.length === 0) return;
  const found = await ctx.db.mediaAsset.findMany({ where: { id: { in: ids } }, select: { id: true } });
  if (found.length !== ids.length)
    throw new AppError(422, "invalid_media", "A referenced image does not exist in this store");
}

const toDto = (a: { id: string; filename: string; mime: string; sizeBytes: number; createdAt: Date }) => ({
  id: a.id,
  url: `/api/media/${a.id}`,
  filename: a.filename,
  mime: a.mime,
  sizeBytes: a.sizeBytes,
  createdAt: a.createdAt,
});
