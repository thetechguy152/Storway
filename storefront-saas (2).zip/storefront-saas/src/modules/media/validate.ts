export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

/**
 * Identify an image by its first bytes. The client's Content-Type and file
 * name are ignored. SVG is intentionally NOT supported (it can carry script).
 */
export function sniffImage(b: Uint8Array): { mime: string; ext: string } | null {
  const at = (i: number) => b[i] ?? -1;
  if (at(0) === 0x89 && at(1) === 0x50 && at(2) === 0x4e && at(3) === 0x47) return { mime: "image/png", ext: "png" };
  if (at(0) === 0xff && at(1) === 0xd8 && at(2) === 0xff) return { mime: "image/jpeg", ext: "jpg" };
  if (at(0) === 0x47 && at(1) === 0x49 && at(2) === 0x46 && at(3) === 0x38) return { mime: "image/gif", ext: "gif" };
  if (
    at(0) === 0x52 && at(1) === 0x49 && at(2) === 0x46 && at(3) === 0x46 &&
    at(8) === 0x57 && at(9) === 0x45 && at(10) === 0x42 && at(11) === 0x50
  )
    return { mime: "image/webp", ext: "webp" };
  return null;
}
