import { createHmac, timingSafeEqual } from "crypto";
import { env } from "@/config/env";

export const PREVIEW_COOKIE = "sf_preview";

const mac = (payload: string) =>
  createHmac("sha256", env().PREVIEW_SECRET).update(payload).digest("base64url");

/** Short-lived signed token: "<storeId>.<expiresAtSeconds>.<signature>". */
export function signPreview(storeId: string, ttlSeconds = 30 * 60) {
  const payload = `${storeId}.${Math.floor(Date.now() / 1000) + ttlSeconds}`;
  return `${payload}.${mac(payload)}`;
}

export function verifyPreview(token: string | undefined): { storeId: string } | null {
  if (!token) return null;
  const [storeId, exp, sig] = token.split(".");
  if (!storeId || !exp || !sig) return null;
  const expected = Buffer.from(mac(`${storeId}.${exp}`));
  const actual = Buffer.from(sig);
  if (expected.length !== actual.length || !timingSafeEqual(expected, actual)) return null;
  if (Number(exp) < Date.now() / 1000) return null;
  return { storeId };
}
