import { prisma, toJson } from "@/server/db";
import { AppError, notFound } from "@/server/errors";
import { audit } from "@/modules/audit/service";
import type { StoreContext } from "@/modules/tenancy/context";
import { assertAssetsOwned } from "@/modules/media/service";
import { BASE_THEMES, PRESETS, STARTERS, getBaseThemeMeta, getPreset } from "@/themes/catalog";
import { sectionsSchema, snapshotSchema, type Section, type ThemeTokens } from "@/themes/schema";

export const themeCatalog = () => ({ baseThemes: BASE_THEMES, presets: PRESETS, starters: STARTERS });

export async function getThemeState(ctx: StoreContext) {
  ctx.require("theme:read");
  const theme = await ctx.db.storeTheme.findFirst();
  if (!theme) throw notFound("Theme");
  const pages = await ctx.db.page.findMany({
    select: { slug: true, title: true, updatedAt: true, published: true },
    orderBy: { slug: "asc" },
  });
  return {
    draft: { baseThemeId: theme.baseThemeId, presetId: theme.presetId, tokens: theme.draftTokens },
    published: theme.publishedAt
      ? { baseThemeId: theme.publishedBaseThemeId, tokens: theme.publishedTokens, publishedAt: theme.publishedAt }
      : null,
    pages: pages.map((p) => ({ slug: p.slug, title: p.title, updatedAt: p.updatedAt, isPublished: p.published !== null })),
  };
}

export async function saveThemeDraft(ctx: StoreContext, input: { baseThemeId: string; tokens: ThemeTokens }) {
  ctx.require("theme:write");
  if (!getBaseThemeMeta(input.baseThemeId))
    throw new AppError(422, "unknown_theme", "Unknown base theme", { baseThemeId: ["Unknown theme"] });
  await ctx.db.storeTheme.update({
    where: { storeId: ctx.storeId },
    data: { baseThemeId: input.baseThemeId, draftTokens: toJson(input.tokens) },
  });
  await audit({ storeId: ctx.storeId, actorId: ctx.userId, action: "theme.draft_saved" });
}

/** Copies a preset INTO the draft. The merchant then owns and can change every value. */
export async function applyPreset(ctx: StoreContext, presetId: string) {
  ctx.require("theme:write");
  const preset = getPreset(presetId);
  if (!preset) throw notFound("Preset");
  await prisma.$transaction(async (tx) => {
    await tx.storeTheme.update({
      where: { storeId: ctx.storeId },
      data: { baseThemeId: preset.baseThemeId, presetId: preset.id, draftTokens: toJson(preset.tokens) },
    });
    await tx.page.upsert({
      where: { storeId_slug: { storeId: ctx.storeId, slug: "home" } },
      create: { storeId: ctx.storeId, slug: "home", title: "Home", draft: toJson(preset.home) },
      update: { draft: toJson(preset.home) },
    });
  });
  await audit({ storeId: ctx.storeId, actorId: ctx.userId, action: "theme.preset_applied", target: presetId });
}

function imageIds(sections: Section[]): string[] {
  const ids = new Set<string>();
  for (const s of sections) {
    const id = "imageId" in s.settings ? s.settings.imageId : undefined;
    if (id) ids.add(id);
  }
  return [...ids];
}

export async function savePageDraft(ctx: StoreContext, slug: string, input: { title: string; sections: Section[] }) {
  ctx.require("theme:write");
  // A section may only reference images from THIS store's media library.
  const ids = imageIds(input.sections);
  if (ids.length && (await ctx.db.media.count({ where: { id: { in: ids } } })) !== ids.length)
    throw new AppError(422, "unknown_image", "A section references an image that isn't in this store");
  const exists = await ctx.db.page.findFirst({ where: { slug }, select: { id: true } });
  if (!exists && (await ctx.db.page.count()) >= 50)
    throw new AppError(422, "page_limit", "Page limit reached");
  await ctx.db.page.upsert({
    where: { storeId_slug: { storeId: ctx.storeId, slug } },
    create: { storeId: ctx.storeId, slug, title: input.title, draft: toJson(input.sections) },
    update: { title: input.title, draft: toJson(input.sections) },
  });
  await audit({ storeId: ctx.storeId, actorId: ctx.userId, action: "page.draft_saved", target: slug });
}

export async function getPageDraft(ctx: StoreContext, slug: string) {
  ctx.require("theme:read");
  const page = await ctx.db.page.findFirst({ where: { slug } });
  if (!page) throw notFound("Page");
  return { slug: page.slug, title: page.title, sections: page.draft };
}

/**
 * "Publish site": atomically promotes the theme draft and every page draft,
 * and records a revision of what went live (used for rollback).
 */
export async function publishSite(ctx: StoreContext) {
  ctx.require("theme:write");
  const { storeId } = ctx;
  const revision = await prisma.$transaction(async (tx) => {
    const theme = await tx.storeTheme.findUniqueOrThrow({ where: { storeId } });
    const pages = await tx.page.findMany({ where: { storeId } });

    await tx.storeTheme.update({
      where: { storeId },
      data: {
        publishedBaseThemeId: theme.baseThemeId,
        publishedTokens: toJson(theme.draftTokens),
        publishedAt: new Date(),
      },
    });
    for (const p of pages) {
      await tx.page.update({ where: { id: p.id }, data: { published: toJson(p.draft) } });
    }
    return tx.themeRevision.create({
      data: {
        storeId,
        createdBy: ctx.userId,
        snapshot: toJson({
          baseThemeId: theme.baseThemeId,
          presetId: theme.presetId,
          tokens: theme.draftTokens,
          pages: pages.map((p) => ({ slug: p.slug, title: p.title, sections: p.draft })),
        }),
      },
    });
  });
  await audit({ storeId, actorId: ctx.userId, action: "site.published", target: revision.id });
  return { revisionId: revision.id };
}

export async function listRevisions(ctx: StoreContext) {
  ctx.require("theme:read");
  return ctx.db.themeRevision.findMany({
    select: { id: true, createdBy: true, createdAt: true },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
}

/** Rollback = load a past revision into the DRAFT; the merchant previews, then publishes. */
export async function restoreRevision(ctx: StoreContext, revisionId: string) {
  ctx.require("theme:write");
  const rev = await ctx.db.themeRevision.findFirst({ where: { id: revisionId } });
  if (!rev) throw notFound("Revision");
  const snap = snapshotSchema.parse(rev.snapshot); // re-validate old data before trusting it

  await prisma.$transaction(async (tx) => {
    await tx.storeTheme.update({
      where: { storeId: ctx.storeId },
      data: { baseThemeId: snap.baseThemeId, presetId: snap.presetId ?? null, draftTokens: toJson(snap.tokens) },
    });
    for (const p of snap.pages) {
      await tx.page.upsert({
        where: { storeId_slug: { storeId: ctx.storeId, slug: p.slug } },
        create: { storeId: ctx.storeId, slug: p.slug, title: p.title, draft: toJson(p.sections) },
        update: { title: p.title, draft: toJson(p.sections) },
      });
    }
  });
  await audit({ storeId: ctx.storeId, actorId: ctx.userId, action: "theme.revision_restored", target: revisionId });
}

/** All page drafts, for the editor. Invalid stored data degrades to an empty page. */
export async function listPageDrafts(ctx: StoreContext) {
  ctx.require("theme:read");
  const pages = await ctx.db.page.findMany({ orderBy: { slug: "asc" } });
  return pages.map((p) => {
    const parsed = sectionsSchema.safeParse(p.draft);
    return { slug: p.slug, title: p.title, sections: parsed.success ? parsed.data : [] };
  });
}
