import { forStore } from "@/server/tenant-db";
import { getBaseThemeMeta } from "@/themes/catalog";
import { sectionsSchema, tokensSchema } from "@/themes/schema";

/**
 * What the storefront renders. `preview` = the merchant's DRAFT (only reachable
 * with a signed preview cookie for THIS store); otherwise the PUBLISHED copy.
 * Stored JSON is re-validated on read, with a safe fallback, so a bad row can
 * never break or exploit a storefront.
 */
export async function getStorefrontTheme(storeId: string, preview: boolean) {
  const row = await forStore(storeId).storeTheme.findFirst();
  const baseThemeId = (preview ? row?.baseThemeId : row?.publishedBaseThemeId) ?? "classic";
  const parsed = tokensSchema.safeParse(preview ? row?.draftTokens : row?.publishedTokens);
  const tokens = parsed.success
    ? parsed.data
    : (getBaseThemeMeta(baseThemeId) ?? getBaseThemeMeta("classic")!).defaultTokens;
  return { baseThemeId, tokens };
}

export async function getStorefrontPage(storeId: string, slug: string, preview: boolean) {
  const page = await forStore(storeId).page.findFirst({ where: { slug } });
  if (!page) return null;
  const raw = preview ? page.draft : page.published;
  if (raw === null) return null; // never published
  const sections = sectionsSchema.safeParse(raw);
  return { title: page.title, sections: sections.success ? sections.data : [] };
}
