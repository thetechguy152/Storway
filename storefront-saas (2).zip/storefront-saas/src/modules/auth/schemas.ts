import { z } from "zod";

export const signupInput = z.object({
  email: z.string().trim().email().max(254),
  password: z.string().min(10, "Use at least 10 characters").max(128),
  name: z.string().trim().min(1).max(100).optional(),
});

export const loginInput = z.object({
  email: z.string().trim().email().max(254),
  password: z.string().min(1).max(128),
});

export const verifyInput = z.object({ token: z.string().min(10).max(200) });
