import { prisma, isUniqueViolation } from "@/server/db";
import { env } from "@/config/env";
import { AppError } from "@/server/errors";
import { hashPassword, verifyPassword, newToken, sha256, normalizeEmail } from "@/server/security";

const DAY = 24 * 60 * 60 * 1000;

/**
 * Always resolves the same way whether or not the email is already registered
 * (prevents account enumeration).
 */
export async function signup(input: { email: string; password: string; name?: string }) {
  const email = normalizeEmail(input.email);
  const passwordHash = await hashPassword(input.password);
  const { token, hash } = newToken();

  try {
    await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({ data: { email, passwordHash, name: input.name } });
      await tx.verificationToken.create({
        data: { userId: user.id, tokenHash: hash, expiresAt: new Date(Date.now() + DAY) },
      });
      // Delivered by the worker process (see src/worker).
      await tx.job.create({ data: { type: "email.verification", payload: { email, token } } });
    });
  } catch (e) {
    if (!isUniqueViolation(e)) throw e; // already registered: stay silent
  }
}

export async function verifyEmail(token: string) {
  const row = await prisma.verificationToken.findUnique({ where: { tokenHash: sha256(token) } });
  if (!row || row.usedAt || row.expiresAt < new Date())
    throw new AppError(400, "invalid_token", "Verification link is invalid or expired");
  await prisma.$transaction([
    prisma.verificationToken.update({ where: { id: row.id }, data: { usedAt: new Date() } }),
    prisma.user.update({ where: { id: row.userId }, data: { verifiedAt: new Date() } }),
  ]);
}

// Verified against when the email is unknown, so response time doesn't reveal it.
let dummyHash: Promise<string> | undefined;

export async function login(
  input: { email: string; password: string },
  meta: { ip?: string; userAgent?: string }
) {
  const user = await prisma.user.findUnique({ where: { email: normalizeEmail(input.email) } });
  const hash = user?.passwordHash ?? (await (dummyHash ??= hashPassword("dummy-password")));
  const valid = await verifyPassword(input.password, hash);

  if (!user || !valid || user.status !== "ACTIVE")
    throw new AppError(401, "invalid_credentials", "Invalid email or password");
  if (!user.verifiedAt)
    throw new AppError(403, "email_not_verified", "Verify your email before signing in");

  const { token, hash: tokenHash } = newToken();
  const ttl = env().SESSION_TTL_DAYS * DAY;
  await prisma.session.create({
    data: { userId: user.id, tokenHash, expiresAt: new Date(Date.now() + ttl), ...meta },
  });
  return { token, maxAgeSeconds: Math.floor(ttl / 1000), user: publicUser(user) };
}

export async function logout(token: string) {
  await prisma.session.updateMany({
    where: { tokenHash: sha256(token), revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

export async function getSessionUser(token: string) {
  const session = await prisma.session.findUnique({
    where: { tokenHash: sha256(token) },
    include: { user: true },
  });
  if (!session || session.revokedAt || session.expiresAt < new Date()) return null;
  if (session.user.status !== "ACTIVE") return null;
  return session.user;
}

export const publicUser = (u: { id: string; email: string; name: string | null }) => ({
  id: u.id,
  email: u.email,
  name: u.name,
});
