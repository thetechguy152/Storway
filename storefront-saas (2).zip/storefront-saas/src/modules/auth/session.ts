import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { env } from "@/config/env";
import { unauthenticated } from "@/server/errors";
import { getSessionUser } from "./service";

export const SESSION_COOKIE = "sid";

export function readToken(req: NextRequest): string | undefined {
  const bearer = req.headers.get("authorization")?.match(/^Bearer (.+)$/)?.[1];
  return req.cookies.get(SESSION_COOKIE)?.value ?? bearer;
}

/** Resolves the signed-in user or throws 401. */
export async function authenticate(req: NextRequest) {
  const token = readToken(req);
  const user = token ? await getSessionUser(token) : null;
  if (!user) throw unauthenticated();
  return user;
}

// Host-only cookie (no Domain attribute): never sent to store subdomains.
export function setSessionCookie(res: NextResponse, token: string, maxAgeSeconds: number) {
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: env().NODE_ENV === "production",
    path: "/",
    maxAge: maxAgeSeconds,
  });
}

export function clearSessionCookie(res: NextResponse) {
  res.cookies.set(SESSION_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
}

/** For server components / pages: the signed-in user from the session cookie, or null. */
export async function getCookieUser() {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  return token ? getSessionUser(token) : null;
}
