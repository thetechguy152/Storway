type Fields = Record<string, unknown>;

function write(level: string, msg: string, fields?: Fields) {
  const line = JSON.stringify({ level, msg, time: new Date().toISOString(), ...fields });
  (level === "error" ? console.error : console.log)(line);
}

export const logger = {
  info: (msg: string, f?: Fields) => write("info", msg, f),
  warn: (msg: string, f?: Fields) => write("warn", msg, f),
  error: (msg: string, f?: Fields) => write("error", msg, f),
};
