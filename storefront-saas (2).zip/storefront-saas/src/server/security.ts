import { createHash, randomBytes, scrypt, timingSafeEqual } from "crypto";

const N = 16384, R = 8, P = 1, KEYLEN = 64;

function derive(password: string, salt: Buffer): Promise<Buffer> {
  return new Promise((resolve, reject) =>
    scrypt(password, salt, KEYLEN, { N, r: R, p: P }, (err, key) => (err ? reject(err) : resolve(key)))
  );
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await derive(password, salt);
  return `scrypt$${N}$${salt.toString("base64")}$${key.toString("base64")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [scheme, , saltB64, keyB64] = stored.split("$");
  if (scheme !== "scrypt" || !saltB64 || !keyB64) return false;
  const expected = Buffer.from(keyB64, "base64");
  const actual = await derive(password, Buffer.from(saltB64, "base64"));
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export const sha256 = (v: string) => createHash("sha256").update(v).digest("hex");

/** Opaque random token; only its hash is stored in the database. */
export function newToken() {
  const token = randomBytes(32).toString("base64url");
  return { token, hash: sha256(token) };
}

export const normalizeEmail = (e: string) => e.trim().toLowerCase();
