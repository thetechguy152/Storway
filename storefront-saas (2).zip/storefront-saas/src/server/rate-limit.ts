import { NextRequest } from "next/server";
import { AppError } from "./errors";

// In-memory fixed window. Fine for one instance; swap the Map for Redis
// (INCR + EXPIRE) when you run more than one web process.
const buckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  if (++b.count > limit) throw new AppError(429, "rate_limited", "Too many requests");
}

export function clientIp(req: NextRequest) {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
}
