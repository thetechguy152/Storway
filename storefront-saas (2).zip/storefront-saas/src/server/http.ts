import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { ZodError, ZodTypeAny, z } from "zod";
import { AppError } from "./errors";
import { isUniqueViolation } from "./db";
import { logger } from "./logger";

type Handler<P> = (
  req: NextRequest,
  ctx: { params: P; requestId: string }
) => Promise<Response>;

/**
 * Wraps a route handler with: request id, same-origin check for mutations,
 * param resolution, and the standard error envelope
 * { error: { code, message, fieldErrors?, requestId } }.
 */
export function route<P extends Record<string, string> = Record<string, string>>(
  handler: Handler<P>
) {
  return async (req: NextRequest, segment: { params: Promise<P> }) => {
    const requestId = req.headers.get("x-request-id") ?? randomUUID();
    try {
      assertSameOrigin(req);
      const params = await segment.params;
      const res = await handler(req, { params, requestId });
      res.headers.set("x-request-id", requestId);
      return res;
    } catch (e) {
      return errorResponse(e, requestId);
    }
  };
}

export function ok<T>(data: T, init?: { status?: number; meta?: object }) {
  return NextResponse.json({ data, meta: init?.meta }, { status: init?.status ?? 200 });
}

export async function parseBody<S extends ZodTypeAny>(req: NextRequest, schema: S): Promise<z.infer<S>> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    throw new AppError(400, "invalid_json", "Request body must be valid JSON");
  }
  return schema.parse(body);
}

const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

/** Cookie auth is CSRF-prone; reject mutations whose Origin differs from our host. */
function assertSameOrigin(req: NextRequest) {
  if (SAFE_METHODS.has(req.method)) return;
  const origin = req.headers.get("origin");
  if (!origin) return;
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  if (new URL(origin).host !== host) throw new AppError(403, "bad_origin", "Cross-origin request blocked");
}

function errorResponse(e: unknown, requestId: string) {
  const body = (status: number, code: string, message: string, fieldErrors?: object) =>
    NextResponse.json(
      { error: { code, message, fieldErrors, requestId } },
      { status, headers: { "x-request-id": requestId } }
    );

  if (e instanceof AppError) return body(e.status, e.code, e.message, e.fieldErrors);
  if (e instanceof ZodError)
    return body(422, "validation_failed", "Validation failed", e.flatten().fieldErrors);
  if (isUniqueViolation(e)) return body(409, "conflict", "Resource already exists");

  logger.error("unhandled", { requestId, err: e instanceof Error ? e.stack : String(e) });
  return body(500, "internal_error", "Something went wrong");
}
