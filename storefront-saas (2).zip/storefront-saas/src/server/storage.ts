import { promises as fs } from "fs";
import path from "path";
import { env } from "@/config/env";

/**
 * Storage port. The default driver writes to local disk (fits self-hosted and
 * single-server installs). For S3/R2, implement this same interface and swap
 * the export below; nothing else in the codebase touches the filesystem.
 */
export interface Storage {
  put(key: string, data: Buffer): Promise<void>;
  get(key: string): Promise<Buffer | null>;
  delete(key: string): Promise<void>;
}

function resolveKey(key: string) {
  const root = path.resolve(env().UPLOAD_DIR);
  const full = path.resolve(root, key);
  if (!full.startsWith(root + path.sep)) throw new Error("Invalid storage key"); // no path traversal
  return full;
}

export const storage: Storage = {
  async put(key, data) {
    const file = resolveKey(key);
    await fs.mkdir(path.dirname(file), { recursive: true });
    await fs.writeFile(file, data);
  },
  async get(key) {
    try {
      return await fs.readFile(resolveKey(key));
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code === "ENOENT") return null;
      throw e;
    }
  },
  async delete(key) {
    await fs.rm(resolveKey(key), { force: true });
  },
};
