export class AppError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public fieldErrors?: Record<string, string[] | undefined>
  ) {
    super(message);
  }
}

export const notFound = (what = "Resource") =>
  new AppError(404, "not_found", `${what} not found`);
export const forbidden = (message = "Forbidden") => new AppError(403, "forbidden", message);
export const unauthenticated = (message = "Authentication required") =>
  new AppError(401, "unauthenticated", message);
