import { prisma } from "./db";

/** Every Prisma model that has a storeId column. Add new tenant tables here. */
const TENANT_MODELS = new Set(["Product", "Variant", "StoreTheme", "Page", "ThemeRevision", "Media"]);

/**
 * Tenant-scoped Prisma client. For tenant models it forces `storeId` into every
 * where/create, so a forgotten filter (or a client-supplied storeId) cannot leak
 * or write across stores. Request handlers use this; never the raw client.
 */
export function forStore(storeId: string) {
  return prisma.$extends({
    name: "tenant-scope",
    query: {
      $allModels: {
        async $allOperations({ model, operation, args, query }) {
          if (!TENANT_MODELS.has(model)) return query(args);
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const a = (args ?? {}) as Record<string, any>;
          switch (operation) {
            case "create":
              a.data = { ...a.data, storeId };
              break;
            case "createMany":
            case "createManyAndReturn":
              a.data = (Array.isArray(a.data) ? a.data : [a.data]).map(
                (d: object) => ({ ...d, storeId })
              );
              break;
            case "upsert":
              a.where = { ...a.where, storeId };
              a.create = { ...a.create, storeId };
              break;
            default:
              a.where = { ...(a.where ?? {}), storeId };
          }
          return query(a);
        },
      },
    },
  });
}

export type TenantDb = ReturnType<typeof forStore>;
