export function slugify(input: string): string {
  return input
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

export function formatMoney(minor: number, currency: string, locale = "en-US") {
  // Assumes 2 decimal places. Zero/three-decimal currencies (JPY, KWD) need
  // an exponent table when you go multi-currency.
  return new Intl.NumberFormat(locale, { style: "currency", currency }).format(minor / 100);
}
