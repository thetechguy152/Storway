import { prisma } from "@/server/db";
import { logger } from "@/server/logger";
import { env } from "@/config/env";

/**
 * Separate process, same codebase: `npm run worker`.
 * Polls the Job table. Delivery is at-least-once, so handlers must be idempotent.
 */
type Handler = (payload: any) => Promise<void>; // eslint-disable-line @typescript-eslint/no-explicit-any

const handlers: Record<string, Handler> = {
  "email.verification": async ({ email, token }) => {
    // Replace with a real provider (Resend, SES, Postmark...).
    logger.info("email.verification (dev: not sent)", {
      to: email,
      link: `${env().APP_URL}/verify?token=${token}`,
    });
  },
};

const MAX_ATTEMPTS = 5;

async function tick(): Promise<boolean> {
  const job = await prisma.job.findFirst({
    where: { status: "PENDING", runAt: { lte: new Date() } },
    orderBy: { runAt: "asc" },
  });
  if (!job) return false;

  // Optimistic claim: only one worker wins the PENDING -> RUNNING transition.
  const claimed = await prisma.job.updateMany({
    where: { id: job.id, status: "PENDING" },
    data: { status: "RUNNING", attempts: { increment: 1 } },
  });
  if (claimed.count === 0) return true;

  const attempts = job.attempts + 1;
  try {
    const handler = handlers[job.type];
    if (!handler) throw new Error(`No handler for ${job.type}`);
    await handler(job.payload);
    await prisma.job.update({ where: { id: job.id }, data: { status: "DONE", lastError: null } });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    const dead = attempts >= MAX_ATTEMPTS;
    logger.error("job failed", { id: job.id, type: job.type, attempts, dead, message });
    await prisma.job.update({
      where: { id: job.id },
      data: {
        status: dead ? "FAILED" : "PENDING",
        lastError: message,
        runAt: new Date(Date.now() + 2 ** attempts * 1000), // exponential backoff
      },
    });
  }
  return true;
}

async function main() {
  logger.info("worker started");
  let stopping = false;
  for (const sig of ["SIGINT", "SIGTERM"]) process.on(sig, () => (stopping = true));

  while (!stopping) {
    const didWork = await tick().catch((e) => {
      logger.error("tick failed", { err: String(e) });
      return false;
    });
    if (!didWork) await new Promise((r) => setTimeout(r, 1000));
  }
  await prisma.$disconnect();
}

main();
