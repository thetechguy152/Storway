import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  DATABASE_URL: z.string().min(1),
  APP_URL: z.string().url().default("http://localhost:3000"),
  ROOT_DOMAIN: z.string().default("localhost:3000"),
  // Signs storefront preview links. MUST be overridden in production.
  PREVIEW_SECRET: z.string().min(16).default("dev-only-preview-secret-change-me"),
  // Local-disk media storage (dev). In production swap the StorageDriver for S3-compatible storage.
  UPLOAD_DIR: z.string().default("./.uploads"),
  UPLOAD_DIR: z.string().default("./uploads"),
  MAX_UPLOAD_MB: z.coerce.number().positive().default(5),
  SESSION_TTL_DAYS: z.coerce.number().int().positive().default(14),
});

let cached: z.infer<typeof schema> | undefined;

/** Validated environment. Throws at first use if misconfigured. */
export function env() {
  return (cached ??= schema.parse(process.env));
}
