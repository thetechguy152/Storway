/**
 * Font allowlist. `google` is the exact CSS2 "family" fragment, so a merchant
 * can only ever pick a key from this table: no arbitrary URLs reach the page.
 * Web fonts load from fonts.googleapis.com (third-party request; self-host
 * them if you need strict GDPR posture).
 */
type FontDef = { label: string; stack: string; google?: string };

export const FONTS = {
  system: { label: "System UI", stack: "system-ui, -apple-system, Segoe UI, sans-serif" },
  serif: { label: "Georgia (serif)", stack: 'Georgia, "Times New Roman", serif' },
  rounded: { label: "Trebuchet (rounded)", stack: '"Trebuchet MS", "Segoe UI", sans-serif' },
  mono: { label: "Monospace", stack: "ui-monospace, Menlo, Consolas, monospace" },
  inter: { label: "Inter", stack: "Inter, system-ui, sans-serif", google: "Inter:wght@400;600;700" },
  poppins: { label: "Poppins", stack: "Poppins, system-ui, sans-serif", google: "Poppins:wght@400;600;700" },
  montserrat: { label: "Montserrat", stack: "Montserrat, system-ui, sans-serif", google: "Montserrat:wght@400;600;700" },
  "dm-sans": { label: "DM Sans", stack: '"DM Sans", system-ui, sans-serif', google: "DM+Sans:wght@400;600;700" },
  raleway: { label: "Raleway", stack: "Raleway, system-ui, sans-serif", google: "Raleway:wght@400;600;700" },
  nunito: { label: "Nunito", stack: "Nunito, system-ui, sans-serif", google: "Nunito:wght@400;600;700" },
  "space-grotesk": { label: "Space Grotesk", stack: '"Space Grotesk", system-ui, sans-serif', google: "Space+Grotesk:wght@400;600;700" },
  oswald: { label: "Oswald", stack: "Oswald, Impact, sans-serif", google: "Oswald:wght@400;600;700" },
  "playfair-display": { label: "Playfair Display", stack: '"Playfair Display", Georgia, serif', google: "Playfair+Display:wght@400;700" },
  lora: { label: "Lora", stack: "Lora, Georgia, serif", google: "Lora:wght@400;600;700" },
  merriweather: { label: "Merriweather", stack: "Merriweather, Georgia, serif", google: "Merriweather:wght@400;700" },
} as const satisfies Record<string, FontDef>;

export type FontKey = keyof typeof FONTS;
export const FONT_KEYS = Object.keys(FONTS) as [FontKey, ...FontKey[]];
export const FONT_STACKS = Object.fromEntries(
  FONT_KEYS.map((k) => [k, FONTS[k].stack])
) as Record<FontKey, string>;

/** Single stylesheet URL for the fonts a theme actually uses, or null. */
export function googleFontsHref(...keys: FontKey[]): string | null {
  const families = [
    ...new Set(
      keys.map((k) => ("google" in FONTS[k] ? (FONTS[k] as FontDef).google : undefined)).filter(Boolean)
    ),
  ];
  if (!families.length) return null;
  return `https://fonts.googleapis.com/css2?${families.map((f) => `family=${f}`).join("&")}&display=swap`;
}
