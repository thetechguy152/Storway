import Link from "next/link";
import type { CSSProperties, ReactNode } from "react";
import { formatMoney } from "@/server/slug";
import type { Section } from "./schema";

// Pure presentational components: no server imports, so the SAME code renders
// the live storefront (server) and the editor canvas (client).

export type StoreInfo = { id: string; name: string; slug: string; currency: string };
export type ProductCard = {
  id: string;
  title: string;
  slug: string;
  variants: { priceMinor: number; currency: string }[];
};

export const mediaUrl = (id: string) => `/api/media/${id}`;

const wrap: CSSProperties = { maxWidth: 960, margin: "0 auto", padding: "32px 24px" };
const heading: CSSProperties = { fontFamily: "var(--font-heading)", margin: "0 0 12px" };
const button: CSSProperties = {
  display: "inline-block",
  padding: "10px 20px",
  background: "var(--color-primary)",
  color: "var(--color-background)",
  borderRadius: "var(--radius)",
  textDecoration: "none",
};

function CtaLink({ href, children }: { href: string; children: ReactNode }) {
  return href.startsWith("/") ? (
    <Link href={href} style={button}>{children}</Link>
  ) : (
    <a href={href} rel="noopener noreferrer" style={button}>{children}</a>
  );
}

function Hero({ s }: { s: Extract<Section, { type: "hero" }> }) {
  const { heading: h, subheading, ctaLabel, ctaHref, align, imageId } = s.settings;
  const bg: CSSProperties = imageId
    ? {
        background: `linear-gradient(rgba(0,0,0,.45), rgba(0,0,0,.45)), url(${mediaUrl(imageId)}) center / cover`,
        color: "#fff",
      }
    : {};
  return (
    <section style={{ textAlign: align, padding: "72px 0", ...bg }}>
      <div style={wrap}>
        <h1 style={{ ...heading, fontSize: "clamp(1.8rem, 6cqi, 2.6rem)" }}>{h}</h1>
        {subheading && <p style={{ fontSize: "1.15rem", opacity: 0.85 }}>{subheading}</p>}
        {ctaLabel && ctaHref && <CtaLink href={ctaHref}>{ctaLabel}</CtaLink>}
      </div>
    </section>
  );
}

function ProductGrid({ s, products }: { s: Extract<Section, { type: "productGrid" }>; products: ProductCard[] }) {
  const shown = products.slice(0, s.settings.limit);
  return (
    <section style={wrap}>
      {s.settings.title && <h2 style={heading}>{s.settings.title}</h2>}
      {shown.length === 0 && <p style={{ opacity: 0.7 }}>No products yet.</p>}
      <ul style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fill,minmax(180px,1fr))", padding: 0, listStyle: "none" }}>
        {shown.map((p) => (
          <li key={p.id} style={{ border: "1px solid color-mix(in srgb, var(--color-text) 15%, transparent)", borderRadius: "var(--radius)", padding: 16 }}>
            <Link href={`/products/${p.slug}`} style={{ color: "var(--color-primary)", fontWeight: 600 }}>{p.title}</Link>
            {p.variants[0] && <div>{formatMoney(p.variants[0].priceMinor, p.variants[0].currency)}</div>}
          </li>
        ))}
      </ul>
    </section>
  );
}

function RichText({ s }: { s: Extract<Section, { type: "richText" }> }) {
  // Plain text rendered as React text nodes: no HTML is ever interpreted.
  return (
    <section style={{ ...wrap, maxWidth: 720 }}>
      {s.settings.heading && <h2 style={heading}>{s.settings.heading}</h2>}
      {s.settings.body.split(/\n{2,}/).map((t, i) => <p key={i}>{t}</p>)}
    </section>
  );
}

function ImageText({ s }: { s: Extract<Section, { type: "imageText" }> }) {
  const { heading: h, body, imageId, imageAlt, imagePosition } = s.settings;
  return (
    <section style={{ ...wrap, display: "flex", flexWrap: "wrap", gap: 32, alignItems: "center", flexDirection: imagePosition === "left" ? "row-reverse" : "row" }}>
      <div style={{ flex: "1 1 280px" }}>
        {h && <h2 style={heading}>{h}</h2>}
        {body.split(/\n{2,}/).map((t, i) => <p key={i}>{t}</p>)}
      </div>
      <div style={{ flex: "1 1 280px" }}>
        {imageId ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={mediaUrl(imageId)} alt={imageAlt} loading="lazy" style={{ width: "100%", height: "auto", borderRadius: "var(--radius)", display: "block" }} />
        ) : (
          <div style={{ aspectRatio: "4/3", background: "color-mix(in srgb, var(--color-text) 8%, transparent)", borderRadius: "var(--radius)" }} />
        )}
      </div>
    </section>
  );
}

export function SectionView({ section, products }: { section: Section; products: ProductCard[] }) {
  switch (section.type) {
    case "hero": return <Hero s={section} />;
    case "productGrid": return <ProductGrid s={section} products={products} />;
    case "richText": return <RichText s={section} />;
    case "imageText": return <ImageText s={section} />;
  }
}
