import type { Section, SectionType } from "./schema";

export const SECTION_TYPES: { type: SectionType; label: string; hint: string }[] = [
  { type: "hero", label: "Hero banner", hint: "Headline, text, button, background image" },
  { type: "productGrid", label: "Product grid", hint: "Your published products" },
  { type: "richText", label: "Text", hint: "Heading and paragraphs" },
  { type: "imageText", label: "Image + text", hint: "Picture next to a message" },
];

export function newSection(type: SectionType, id: string): Section {
  switch (type) {
    case "hero":
      return { id, type, settings: { heading: "Your headline", subheading: "Supporting text", ctaLabel: "Shop now", ctaHref: "/", align: "center" } };
    case "productGrid":
      return { id, type, settings: { title: "Products", limit: 8 } };
    case "richText":
      return { id, type, settings: { heading: "Heading", body: "Write something about your store." } };
    case "imageText":
      return { id, type, settings: { heading: "Our story", body: "Tell customers more.", imageAlt: "", imagePosition: "right" } };
  }
}
