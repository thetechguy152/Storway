import type { ReactNode } from "react";
import { getThemeImpl, tokenVars } from "./registry";
import { FONT_STACKS, googleFontsHref } from "./fonts";
import type { ThemeTokens } from "./schema";
import type { StoreInfo } from "./Sections";

/** Applies tokens as CSS variables, loads the chosen web fonts, wraps in the theme layout. */
export function ThemeFrame(props: {
  store: StoreInfo;
  baseThemeId: string;
  tokens: ThemeTokens;
  showPreviewBar: boolean;
  children: ReactNode;
}) {
  const { store, baseThemeId, tokens, showPreviewBar, children } = props;
  const { Layout } = getThemeImpl(baseThemeId);
  const fontsHref = googleFontsHref(tokens.fonts.heading, tokens.fonts.body);

  return (
    <div
      style={{
        ...tokenVars(tokens),
        background: "var(--color-background)",
        color: "var(--color-text)",
        fontFamily: FONT_STACKS[tokens.fonts.body],
        minHeight: "100vh",
      }}
    >
      {fontsHref && (
        <>
          <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
          <link rel="stylesheet" href={fontsHref} precedence="default" />
        </>
      )}
      <Layout store={store} preview={showPreviewBar}>{children}</Layout>
    </div>
  );
}
