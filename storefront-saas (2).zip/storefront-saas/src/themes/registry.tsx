import Link from "next/link";
import type { CSSProperties, ReactNode } from "react";
import { FONT_STACKS, RADIUS, type ThemeTokens } from "./schema";
import type { StoreInfo } from "./sectionViews";

export type LayoutProps = { store: StoreInfo; preview: boolean; children: ReactNode };
export type ThemeImpl = { id: string; Layout: (props: LayoutProps) => ReactNode };

/** Validated tokens -> CSS custom properties. Only allowlisted values get here. */
export function tokenVars(t: ThemeTokens): CSSProperties {
  return {
    "--color-primary": t.colors.primary,
    "--color-background": t.colors.background,
    "--color-text": t.colors.text,
    "--color-accent": t.colors.accent,
    "--font-heading": FONT_STACKS[t.fonts.heading],
    "--font-body": FONT_STACKS[t.fonts.body],
    "--radius": RADIUS[t.radius],
  } as CSSProperties;
}

function PreviewBar({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <div style={{ background: "#facc15", color: "#000", padding: "6px 12px", fontSize: 13, textAlign: "center" }}>
      Preview of your unpublished changes. <a href="/api/preview?exit=1">Exit preview</a>
    </div>
  );
}

const nav = (
  <nav style={{ display: "flex", gap: 16 }}>
    <Link href="/" style={{ color: "inherit" }}>Home</Link>
  </nav>
);

function Footer({ store }: { store: StoreInfo }) {
  return (
    <footer style={{ padding: 24, textAlign: "center", opacity: 0.7, fontSize: 14 }}>
      © {new Date().getFullYear()} {store.name}
    </footer>
  );
}

const Classic: ThemeImpl = {
  id: "classic",
  Layout: ({ store, preview, children }) => (
    <>
      <PreviewBar show={preview} />
      <header style={{ textAlign: "center", padding: "24px 16px", borderBottom: "1px solid color-mix(in srgb, var(--color-text) 15%, transparent)" }}>
        <div style={{ fontFamily: "var(--font-heading)", fontSize: "1.8rem", color: "var(--color-primary)" }}>{store.name}</div>
        <div style={{ marginTop: 8, display: "flex", justifyContent: "center" }}>{nav}</div>
      </header>
      {children}
      <Footer store={store} />
    </>
  ),
};

const Modern: ThemeImpl = {
  id: "modern",
  Layout: ({ store, preview, children }) => (
    <>
      <PreviewBar show={preview} />
      <header style={{ display: "flex", flexWrap: "wrap", gap: 12, justifyContent: "space-between", alignItems: "center", padding: "20px 32px" }}>
        <div style={{ fontWeight: 700, letterSpacing: 1, textTransform: "uppercase" }}>{store.name}</div>
        {nav}
      </header>
      {children}
      <Footer store={store} />
    </>
  ),
};

const Bold: ThemeImpl = {
  id: "bold",
  Layout: ({ store, preview, children }) => (
    <>
      <PreviewBar show={preview} />
      <header style={{ background: "var(--color-primary)", color: "var(--color-background)", padding: "20px 32px", display: "flex", flexWrap: "wrap", gap: 12, justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontFamily: "var(--font-heading)", fontSize: "1.6rem", fontWeight: 800 }}>{store.name}</div>
        {nav}
      </header>
      {children}
      <Footer store={store} />
    </>
  ),
};

const IMPLS: Record<string, ThemeImpl> = { classic: Classic, modern: Modern, bold: Bold };

/** Unknown/removed theme ids fall back to Classic instead of breaking the storefront. */
export const getThemeImpl = (id: string): ThemeImpl => IMPLS[id] ?? Classic;
