import { z } from "zod";

/**
 * Everything a merchant can configure is validated here, on every write AND
 * on every read. There is no raw HTML/CSS/JS in theme data: only allowlisted
 * tokens and typed sections, so a store can't inject script into its storefront.
 */
const hex = z.string().regex(/^#[0-9a-fA-F]{6}$/, "Use a 6-digit hex color");

/**
 * Font allowlist. `google` is the exact family spec used to build the Google
 * Fonts URL; merchants only pick a KEY, never a URL or family string.
 */
export const FONTS = {
  system: { label: "System", stack: "system-ui, -apple-system, Segoe UI, sans-serif", google: null },
  serif: { label: "Serif (Georgia)", stack: 'Georgia, "Times New Roman", serif', google: null },
  rounded: { label: "Rounded (Trebuchet)", stack: '"Trebuchet MS", "Segoe UI", sans-serif', google: null },
  mono: { label: "Monospace", stack: "ui-monospace, Menlo, Consolas, monospace", google: null },
  inter: { label: "Inter", stack: '"Inter", system-ui, sans-serif', google: "Inter:wght@400;600;700" },
  roboto: { label: "Roboto", stack: '"Roboto", system-ui, sans-serif', google: "Roboto:wght@400;500;700" },
  poppins: { label: "Poppins", stack: '"Poppins", system-ui, sans-serif', google: "Poppins:wght@400;600;700" },
  montserrat: { label: "Montserrat", stack: '"Montserrat", system-ui, sans-serif', google: "Montserrat:wght@400;600;700" },
  dmsans: { label: "DM Sans", stack: '"DM Sans", system-ui, sans-serif', google: "DM+Sans:wght@400;600;700" },
  nunito: { label: "Nunito", stack: '"Nunito", system-ui, sans-serif', google: "Nunito:wght@400;600;700" },
  oswald: { label: "Oswald", stack: '"Oswald", Impact, sans-serif', google: "Oswald:wght@400;600;700" },
  playfair: { label: "Playfair Display", stack: '"Playfair Display", Georgia, serif', google: "Playfair+Display:wght@400;600;700" },
  lora: { label: "Lora", stack: '"Lora", Georgia, serif', google: "Lora:wght@400;600;700" },
  merriweather: { label: "Merriweather", stack: '"Merriweather", Georgia, serif', google: "Merriweather:wght@400;700" },
} as const;

export type FontKey = keyof typeof FONTS;
export const FONT_KEYS = Object.keys(FONTS) as [FontKey, ...FontKey[]];
export const FONT_STACKS = Object.fromEntries(
  Object.entries(FONTS).map(([k, v]) => [k, v.stack])
) as Record<FontKey, string>;
const fontKey = z.enum(FONT_KEYS);

export const RADIUS = { none: "0px", sm: "4px", md: "8px", lg: "16px" } as const;

export const tokensSchema = z.object({
  colors: z.object({ primary: hex, background: hex, text: hex, accent: hex }),
  fonts: z.object({ heading: fontKey, body: fontKey }),
  radius: z.enum(["none", "sm", "md", "lg"]),
});
export type ThemeTokens = z.infer<typeof tokensSchema>;

/** Google Fonts stylesheet URL for the fonts a theme uses (null if none needed). */
export function googleFontsHref(t: ThemeTokens): string | null {
  const families = new Set<string>();
  for (const k of [t.fonts.heading, t.fonts.body]) {
    const g = FONTS[k].google;
    if (g) families.add(g);
  }
  if (families.size === 0) return null;
  return `https://fonts.googleapis.com/css2?${[...families].map((f) => `family=${f}`).join("&")}&display=swap`;
}

// CTA links: same-site path or https URL only (blocks javascript: URLs).
const href = z
  .string()
  .max(300)
  .refine((v) => /^\/[a-zA-Z0-9/_\-?=&#.]*$/.test(v) || /^https:\/\//.test(v), "Use a /path or https:// link");

const id = z.string().min(1).max(40);
// Images are referenced by media asset id, never by URL. The server also checks
// the asset belongs to the same store (see modules/media/service.ts).
const imageId = z.string().uuid();

export const sectionSchema = z.discriminatedUnion("type", [
  z.object({
    id,
    type: z.literal("hero"),
    settings: z.object({
      heading: z.string().max(120),
      subheading: z.string().max(300).optional(),
      ctaLabel: z.string().max(40).optional(),
      ctaHref: href.optional(),
      align: z.enum(["left", "center"]).default("center"),
      imageId: imageId.optional(), // background image
    }),
  }),
  z.object({
    id,
    type: z.literal("productGrid"),
    settings: z.object({
      title: z.string().max(120).optional(),
      limit: z.number().int().min(1).max(24).default(8),
    }),
  }),
  z.object({
    id,
    type: z.literal("richText"),
    // Plain text only; paragraphs split on blank lines. Never rendered as HTML.
    settings: z.object({ heading: z.string().max(120).optional(), body: z.string().max(5000) }),
  }),
  z.object({
    id,
    type: z.literal("imageText"),
    settings: z.object({
      heading: z.string().max(120).optional(),
      body: z.string().max(2000),
      imageId: imageId.optional(),
      imageAlt: z.string().max(200).default(""),
      imagePosition: z.enum(["left", "right"]).default("right"),
    }),
  }),
]);
export type Section = z.infer<typeof sectionSchema>;
export type SectionType = Section["type"];
export const sectionsSchema = z.array(sectionSchema).max(30);

export function collectImageIds(sections: Section[]): string[] {
  const ids = new Set<string>();
  for (const s of sections) {
    if ((s.type === "hero" || s.type === "imageText") && s.settings.imageId) ids.add(s.settings.imageId);
  }
  return [...ids];
}

export const pageSlugSchema = z
  .string()
  .trim()
  .toLowerCase()
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/)
  .max(40);

export const saveDraftInput = z.object({
  baseThemeId: z.string().min(1).max(40),
  tokens: tokensSchema,
});

export const savePageInput = z.object({
  title: z.string().trim().min(1).max(120),
  sections: sectionsSchema,
});

export const snapshotSchema = z.object({
  baseThemeId: z.string(),
  presetId: z.string().nullable().optional(),
  tokens: tokensSchema,
  pages: z.array(z.object({ slug: pageSlugSchema, title: z.string(), sections: sectionsSchema })).max(60),
});
