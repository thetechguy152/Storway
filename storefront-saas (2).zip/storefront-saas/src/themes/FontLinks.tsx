import { googleFontsHref, type ThemeTokens } from "./schema";

/**
 * Loads only the allowlisted Google fonts the theme uses. React 19 hoists
 * these <link>s into <head>. (Privacy note: this makes visitors' browsers
 * contact Google; self-host the font files if you need GDPR-strict setups.)
 */
export function FontLinks({ tokens }: { tokens: ThemeTokens }) {
  const href = googleFontsHref(tokens);
  if (!href) return null;
  return (
    <>
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      <link rel="stylesheet" href={href} precedence="default" />
    </>
  );
}
