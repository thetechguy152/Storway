import type { Section, ThemeTokens } from "./schema";

/**
 * Pure data: base themes, industry presets and page starters.
 * Presets and starters are TEMPLATES: applying one copies its values into the
 * store's own draft, which the merchant can then change freely.
 * The React implementation of each base theme lives in registry.tsx.
 */
export type BaseThemeMeta = { id: string; name: string; description: string; defaultTokens: ThemeTokens };

export const BASE_THEMES: BaseThemeMeta[] = [
  {
    id: "classic",
    name: "Classic",
    description: "Centered header, serif headings, timeless layout.",
    defaultTokens: {
      colors: { primary: "#1f3a5f", background: "#ffffff", text: "#1a1a1a", accent: "#b8860b" },
      fonts: { heading: "serif", body: "system" },
      radius: "sm",
    },
  },
  {
    id: "modern",
    name: "Modern",
    description: "Minimal left-aligned header, airy spacing, rounded corners.",
    defaultTokens: {
      colors: { primary: "#111111", background: "#fafafa", text: "#222222", accent: "#ff5a36" },
      fonts: { heading: "system", body: "system" },
      radius: "lg",
    },
  },
  {
    id: "bold",
    name: "Bold",
    description: "High-contrast color header band and big type.",
    defaultTokens: {
      colors: { primary: "#6d28d9", background: "#ffffff", text: "#111827", accent: "#f59e0b" },
      fonts: { heading: "rounded", body: "rounded" },
      radius: "md",
    },
  },
];

export const getBaseThemeMeta = (id: string) => BASE_THEMES.find((t) => t.id === id);

export type Preset = {
  id: string;
  name: string;
  industry: string;
  baseThemeId: string;
  tokens: ThemeTokens;
  home: Section[];
};

function home(heading: string, sub: string, cta: string, gridTitle: string): Section[] {
  return [
    { id: "hero-1", type: "hero", settings: { heading, subheading: sub, ctaLabel: cta, ctaHref: "/", align: "center" } },
    { id: "grid-1", type: "productGrid", settings: { title: gridTitle, limit: 8 } },
  ];
}

// A handful of examples. Adding the rest of the 37 industry presets is data-only:
// append objects here, no new code. tests/unit/themes.test.ts validates every one.
export const PRESETS: Preset[] = [
  {
    id: "general-classic",
    name: "General Store",
    industry: "general",
    baseThemeId: "classic",
    tokens: BASE_THEMES[0]!.defaultTokens,
    home: home("Welcome to our store", "Quality products, delivered.", "Shop now", "Featured products"),
  },
  {
    id: "fashion-modern",
    name: "Fashion Boutique",
    industry: "fashion",
    baseThemeId: "modern",
    tokens: { ...BASE_THEMES[1]!.defaultTokens, colors: { primary: "#1c1917", background: "#fafaf9", text: "#292524", accent: "#be123c" } },
    home: home("The new season", "Pieces made to be worn.", "Explore the collection", "New arrivals"),
  },
  {
    id: "jewelry-classic",
    name: "Fine Jewelry",
    industry: "jewelry",
    baseThemeId: "classic",
    tokens: { ...BASE_THEMES[0]!.defaultTokens, colors: { primary: "#3b2f2f", background: "#fffdf8", text: "#2a2323", accent: "#c9a227" } },
    home: home("Crafted to last", "Handmade jewelry with a story.", "View pieces", "Bestsellers"),
  },
  {
    id: "electronics-bold",
    name: "Electronics",
    industry: "electronics",
    baseThemeId: "bold",
    tokens: { ...BASE_THEMES[2]!.defaultTokens, colors: { primary: "#0f172a", background: "#ffffff", text: "#0f172a", accent: "#22d3ee" } },
    home: home("Tech that works", "Top gear at fair prices.", "Shop deals", "Hot right now"),
  },
  {
    id: "food-classic",
    name: "Food & Grocery",
    industry: "food",
    baseThemeId: "classic",
    tokens: { ...BASE_THEMES[0]!.defaultTokens, colors: { primary: "#166534", background: "#fffef7", text: "#1c1917", accent: "#ea580c" }, fonts: { heading: "serif", body: "rounded" } },
    home: home("Fresh, local, delicious", "From our kitchen to your table.", "Order now", "Popular picks"),
  },
];

export const DEFAULT_PRESET_ID = "general-classic";
export const getPreset = (id: string) => PRESETS.find((p) => p.id === id);

export type PageStarter = { id: string; name: string; slug: string; title: string; sections: Section[] };

// 3 examples of the 24 planned starters; same data-only extension model.
export const STARTERS: PageStarter[] = [
  {
    id: "about",
    name: "About us",
    slug: "about",
    title: "About us",
    sections: [
      { id: "t-1", type: "richText", settings: { heading: "Our story", body: "Tell customers who you are and why you started.\n\nShare what makes your products different." } },
    ],
  },
  {
    id: "contact",
    name: "Contact",
    slug: "contact",
    title: "Contact",
    sections: [
      { id: "t-1", type: "richText", settings: { heading: "Get in touch", body: "Email us at hello@example.com. We reply within one business day." } },
    ],
  },
  {
    id: "landing-promo",
    name: "Promo landing page",
    slug: "promo",
    title: "Promotion",
    sections: [
      { id: "h-1", type: "hero", settings: { heading: "Limited-time offer", subheading: "Don't miss out.", ctaLabel: "Shop the sale", ctaHref: "/", align: "left" } },
      { id: "g-1", type: "productGrid", settings: { title: "On sale", limit: 12 } },
    ],
  },
];
