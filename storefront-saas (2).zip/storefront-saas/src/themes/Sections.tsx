import { listPublishedProducts } from "@/modules/storefront/queries";
import type { Section } from "./schema";
import { SectionView, type StoreInfo } from "./sectionViews";

/** Server wrapper: one product query for the page, then pure views. */
export async function Sections({ sections, store }: { sections: Section[]; store: StoreInfo }) {
  const limits = sections.flatMap((s) => (s.type === "productGrid" ? [s.settings.limit] : []));
  const products = limits.length ? await listPublishedProducts(store.id, Math.max(...limits)) : [];
  return (
    <>
      {sections.map((s) => (
        <SectionView key={s.id} section={s} products={products} />
      ))}
    </>
  );
}
