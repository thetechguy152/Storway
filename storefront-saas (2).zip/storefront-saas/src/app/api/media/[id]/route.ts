import { NextResponse } from "next/server";
import { route } from "@/server/http";
import { prisma } from "@/server/db";
import { notFound } from "@/server/errors";
import { getStorage } from "@/modules/media/storage";

// Public by design (storefront images). Lookup is by unguessable UUID; the
// storage key always comes from the database row, never from the request.
export const GET = route<{ id: string }>(async (_req, { params }) => {
  if (!/^[0-9a-f-]{36}$/.test(params.id)) throw notFound("Media");
  const media = await prisma.media.findUnique({ where: { id: params.id } });
  if (!media) throw notFound("Media");

  const bytes = await getStorage().get(media.key).catch(() => {
    throw notFound("Media");
  });
  return new NextResponse(new Uint8Array(bytes), {
    headers: {
      "content-type": media.mime,
      "cache-control": "public, max-age=31536000, immutable",
      "x-content-type-options": "nosniff",
      "content-security-policy": "default-src 'none'; sandbox",
    },
  });
});
