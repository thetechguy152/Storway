import { route } from "@/server/http";
import { prisma } from "@/server/db";
import { notFound } from "@/server/errors";
import { storage } from "@/server/storage";

export const dynamic = "force-dynamic";

// Public by design: images appear on public storefronts. Ids are random UUIDs,
// content type comes from magic-byte sniffing at upload time (never from the client),
// and the response forbids sniffing/script execution.
export const GET = route<{ assetId: string }>(async (_req, { params }) => {
  const asset = await prisma.mediaAsset.findUnique({ where: { id: params.assetId } });
  if (!asset) throw notFound("Media");
  const data = await storage.get(asset.key);
  if (!data) throw notFound("Media");
  return new Response(new Uint8Array(data), {
    headers: {
      "content-type": asset.mime,
      "content-length": String(data.length),
      "cache-control": "public, max-age=31536000, immutable",
      "x-content-type-options": "nosniff",
      "content-security-policy": "default-src 'none'; sandbox",
    },
  });
});
