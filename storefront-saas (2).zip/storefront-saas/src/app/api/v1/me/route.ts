import { route, ok } from "@/server/http";
import { authenticate } from "@/modules/auth/session";
import { publicUser } from "@/modules/auth/service";
import { listStoresForUser } from "@/modules/tenancy/service";

export const GET = route(async (req) => {
  const user = await authenticate(req);
  return ok({ user: publicUser(user), stores: await listStoresForUser(user.id) });
});
