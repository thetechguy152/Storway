import { route, ok } from "@/server/http";
import { authenticate } from "@/modules/auth/session";
import { themeCatalog } from "@/modules/theme/service";

// Public-to-merchants catalog: base themes, industry presets, page starters.
export const GET = route(async (req) => {
  await authenticate(req);
  return ok(themeCatalog());
});
