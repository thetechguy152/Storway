import { route, ok, parseBody } from "@/server/http";
import { verifyInput } from "@/modules/auth/schemas";
import { verifyEmail } from "@/modules/auth/service";

export const POST = route(async (req) => {
  await verifyEmail((await parseBody(req, verifyInput)).token);
  return ok({ verified: true });
});
