import { route, ok, parseBody } from "@/server/http";
import { rateLimit, clientIp } from "@/server/rate-limit";
import { signupInput } from "@/modules/auth/schemas";
import { signup } from "@/modules/auth/service";

export const POST = route(async (req) => {
  rateLimit(`signup:${clientIp(req)}`, 5, 60 * 60 * 1000);
  await signup(await parseBody(req, signupInput));
  // Same response whether or not the email already exists.
  return ok({ message: "If the address is valid, a verification email is on its way." }, { status: 202 });
});
