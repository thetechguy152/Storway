import { route, ok, parseBody } from "@/server/http";
import { rateLimit, clientIp } from "@/server/rate-limit";
import { loginInput } from "@/modules/auth/schemas";
import { login } from "@/modules/auth/service";
import { setSessionCookie } from "@/modules/auth/session";

export const POST = route(async (req) => {
  const ip = clientIp(req);
  const input = await parseBody(req, loginInput);
  rateLimit(`login:${ip}`, 20, 15 * 60 * 1000);
  rateLimit(`login:${input.email.toLowerCase()}`, 8, 15 * 60 * 1000);

  const { token, maxAgeSeconds, user } = await login(input, {
    ip,
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  const res = ok({ user });
  setSessionCookie(res, token, maxAgeSeconds);
  return res;
});
