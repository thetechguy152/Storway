import { route, ok } from "@/server/http";
import { logout } from "@/modules/auth/service";
import { readToken, clearSessionCookie } from "@/modules/auth/session";

export const POST = route(async (req) => {
  const token = readToken(req);
  if (token) await logout(token);
  const res = ok({ signedOut: true });
  clearSessionCookie(res);
  return res;
});
