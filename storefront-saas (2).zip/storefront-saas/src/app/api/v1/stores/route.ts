import { route, ok, parseBody } from "@/server/http";
import { authenticate } from "@/modules/auth/session";
import { createStoreInput } from "@/modules/tenancy/schemas";
import { provisionStore, listStoresForUser } from "@/modules/tenancy/service";

export const GET = route(async (req) => {
  const user = await authenticate(req);
  return ok(await listStoresForUser(user.id));
});

export const POST = route(async (req) => {
  const user = await authenticate(req);
  const store = await provisionStore(user.id, await parseBody(req, createStoreInput));
  return ok(store, { status: 201 });
});
