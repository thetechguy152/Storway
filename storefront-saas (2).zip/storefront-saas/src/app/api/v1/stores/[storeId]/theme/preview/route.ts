import { route, ok } from "@/server/http";
import { env } from "@/config/env";
import { prisma } from "@/server/db";
import { requireStoreContext } from "@/modules/tenancy/context";
import { signPreview } from "@/modules/theme/preview";

// Returns a link that opens the storefront showing the DRAFT (30 minutes).
export const POST = route<{ storeId: string }>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  ctx.require("theme:read");
  const store = await prisma.store.findUniqueOrThrow({ where: { id: ctx.storeId }, select: { slug: true } });
  const protocol = new URL(env().APP_URL).protocol;
  const url = `${protocol}//${store.slug}.${env().ROOT_DOMAIN}/api/preview?token=${signPreview(ctx.storeId)}`;
  return ok({ url, expiresInSeconds: 1800 });
});
