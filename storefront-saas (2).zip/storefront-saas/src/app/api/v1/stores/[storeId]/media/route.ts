import { route, ok } from "@/server/http";
import { AppError } from "@/server/errors";
import { requireStoreContext } from "@/modules/tenancy/context";
import { listMedia, uploadImage } from "@/modules/media/service";

type P = { storeId: string };

export const GET = route<P>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  return ok(await listMedia(ctx));
});

export const POST = route<P>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) throw new AppError(400, "file_required", 'Send multipart/form-data with a "file" field');
  return ok(await uploadImage(ctx, file), { status: 201 });
});
