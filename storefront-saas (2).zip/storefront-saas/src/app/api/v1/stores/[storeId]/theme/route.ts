import { route, ok, parseBody } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { getThemeState, saveThemeDraft } from "@/modules/theme/service";
import { saveDraftInput } from "@/themes/schema";

type P = { storeId: string };

export const GET = route<P>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  return ok(await getThemeState(ctx));
});

export const PUT = route<P>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  await saveThemeDraft(ctx, await parseBody(req, saveDraftInput));
  return ok(await getThemeState(ctx));
});
