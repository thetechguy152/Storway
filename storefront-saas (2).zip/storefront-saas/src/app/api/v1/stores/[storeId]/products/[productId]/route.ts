import { route, ok, parseBody } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { updateProductInput } from "@/modules/catalog/schemas";
import { getProduct, updateProduct } from "@/modules/catalog/service";

type P = { storeId: string; productId: string };

export const GET = route<P>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  return ok(await getProduct(ctx, params.productId));
});

export const PATCH = route<P>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  return ok(await updateProduct(ctx, params.productId, await parseBody(req, updateProductInput)));
});
