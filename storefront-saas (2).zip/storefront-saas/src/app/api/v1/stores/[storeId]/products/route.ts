import { route, ok, parseBody } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { createProductInput, listProductsQuery } from "@/modules/catalog/schemas";
import { createProduct, listProducts } from "@/modules/catalog/service";

export const GET = route<{ storeId: string }>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  const q = listProductsQuery.parse(Object.fromEntries(req.nextUrl.searchParams));
  const { items, nextCursor } = await listProducts(ctx, q);
  return ok(items, { meta: { nextCursor } });
});

export const POST = route<{ storeId: string }>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  const product = await createProduct(ctx, await parseBody(req, createProductInput));
  return ok(product, { status: 201 });
});
