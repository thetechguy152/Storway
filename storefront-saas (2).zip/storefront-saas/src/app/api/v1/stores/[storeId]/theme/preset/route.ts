import { z } from "zod";
import { route, ok, parseBody } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { applyPreset, getThemeState } from "@/modules/theme/service";

export const POST = route<{ storeId: string }>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  const { presetId } = await parseBody(req, z.object({ presetId: z.string().min(1).max(60) }));
  await applyPreset(ctx, presetId);
  return ok(await getThemeState(ctx));
});
