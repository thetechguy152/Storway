import { route, ok } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { restoreRevision } from "@/modules/theme/service";

export const POST = route<{ storeId: string; revisionId: string }>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  await restoreRevision(ctx, params.revisionId);
  return ok({ restoredToDraft: true });
});
