import { route, ok } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { listRevisions } from "@/modules/theme/service";

export const GET = route<{ storeId: string }>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  return ok(await listRevisions(ctx));
});
