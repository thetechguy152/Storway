import { route, ok } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { publishProduct } from "@/modules/catalog/service";

export const POST = route<{ storeId: string; productId: string }>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  return ok(await publishProduct(ctx, params.productId));
});
