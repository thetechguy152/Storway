import { route, ok, parseBody } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { getPageDraft, savePageDraft } from "@/modules/theme/service";
import { pageSlugSchema, savePageInput } from "@/themes/schema";

type P = { storeId: string; slug: string };

export const GET = route<P>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  return ok(await getPageDraft(ctx, pageSlugSchema.parse(params.slug)));
});

export const PUT = route<P>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  const slug = pageSlugSchema.parse(params.slug);
  await savePageDraft(ctx, slug, await parseBody(req, savePageInput));
  return ok(await getPageDraft(ctx, slug));
});
