import { route, ok } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { prisma } from "@/server/db";

export const GET = route<{ storeId: string }>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  const store = await prisma.store.findUniqueOrThrow({
    where: { id: ctx.storeId },
    select: { id: true, name: true, slug: true, currency: true, timezone: true, status: true },
  });
  return ok({ ...store, permissions: ctx.permissions });
});
