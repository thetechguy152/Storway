import { route, ok } from "@/server/http";
import { requireStoreContext } from "@/modules/tenancy/context";
import { publishSite } from "@/modules/theme/service";

export const POST = route<{ storeId: string }>(async (req, { params }) => {
  const ctx = await requireStoreContext(req, params.storeId);
  return ok(await publishSite(ctx));
});
