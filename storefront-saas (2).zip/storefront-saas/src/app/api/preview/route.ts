import { NextRequest, NextResponse } from "next/server";
import { PREVIEW_COOKIE, verifyPreview } from "@/modules/theme/preview";
import { env } from "@/config/env";

export const dynamic = "force-dynamic";

export function GET(req: NextRequest) {
  const res = NextResponse.redirect(new URL("/", req.url));
  if (req.nextUrl.searchParams.get("exit")) {
    res.cookies.set(PREVIEW_COOKIE, "", { path: "/", maxAge: 0 });
    return res;
  }
  const token = req.nextUrl.searchParams.get("token") ?? undefined;
  if (!verifyPreview(token)) return new NextResponse("Invalid or expired preview link", { status: 401 });
  res.cookies.set(PREVIEW_COOKIE, token!, {
    httpOnly: true,
    sameSite: "lax",
    secure: env().NODE_ENV === "production",
    path: "/",
    maxAge: 30 * 60,
  });
  return res;
}
