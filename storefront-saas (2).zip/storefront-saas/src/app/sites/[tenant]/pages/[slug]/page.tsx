import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { cookies } from "next/headers";
import { resolveTenant } from "@/modules/tenancy/host";
import { getStorefrontPage } from "@/modules/theme/storefront";
import { PREVIEW_COOKIE, verifyPreview } from "@/modules/theme/preview";
import { pageSlugSchema } from "@/themes/schema";
import { Sections } from "@/themes/Sections";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ tenant: string; slug: string }> };

async function load({ params }: Props) {
  const { tenant, slug } = await params;
  const store = await resolveTenant(decodeURIComponent(tenant));
  const parsed = pageSlugSchema.safeParse(slug);
  if (!store || !parsed.success) return null;
  const preview = verifyPreview((await cookies()).get(PREVIEW_COOKIE)?.value)?.storeId === store.id;
  const page = await getStorefrontPage(store.id, parsed.data, preview);
  return page ? { store, page } : null;
}

export async function generateMetadata(props: Props): Promise<Metadata> {
  const data = await load(props);
  return { title: data ? `${data.page.title} | ${data.store.name}` : "Not found" };
}

export default async function CustomPage(props: Props) {
  const data = await load(props);
  if (!data) notFound();
  return <Sections sections={data.page.sections} store={data.store} />;
}
