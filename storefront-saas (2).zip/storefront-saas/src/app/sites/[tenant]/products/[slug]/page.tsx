import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { resolveTenant } from "@/modules/tenancy/host";
import { getPublishedProduct } from "@/modules/storefront/queries";
import { formatMoney } from "@/server/slug";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ tenant: string; slug: string }> };

async function load(p: Props["params"]) {
  const { tenant, slug } = await p;
  const store = await resolveTenant(decodeURIComponent(tenant));
  if (!store) return null;
  const product = await getPublishedProduct(store.id, slug);
  return product ? { store, product } : null;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const data = await load(params);
  if (!data) return { title: "Not found" };
  const seo = (data.product.seo ?? {}) as { title?: string; description?: string };
  return {
    title: `${seo.title ?? data.product.title} | ${data.store.name}`,
    description: seo.description ?? data.product.description?.slice(0, 160),
  };
}

export default async function ProductPage({ params }: Props) {
  const data = await load(params);
  if (!data) notFound();
  const { store, product } = data;

  return (
    <main style={{ maxWidth: 720, margin: "0 auto", padding: 24 }}>
      <Link href="/">← {store.name}</Link>
      <h1>{product.title}</h1>
      <p>{product.description}</p>
      <ul>
        {product.variants.map((v) => (
          <li key={v.id}>
            {Object.values(v.options as Record<string, string>).join(" / ") || "Default"} —{" "}
            {formatMoney(v.priceMinor, v.currency)}
          </li>
        ))}
      </ul>
      {/* Cart + checkout land here (Sprint 6). */}
    </main>
  );
}
