import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { cookies } from "next/headers";
import { resolveTenant } from "@/modules/tenancy/host";
import { getStorefrontPage } from "@/modules/theme/storefront";
import { PREVIEW_COOKIE, verifyPreview } from "@/modules/theme/preview";
import { Sections } from "@/themes/Sections";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ tenant: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const store = await resolveTenant(decodeURIComponent((await params).tenant));
  return { title: store?.name ?? "Store not found" };
}

export default async function StoreHome({ params }: Props) {
  const store = await resolveTenant(decodeURIComponent((await params).tenant));
  if (!store) notFound();
  const preview = verifyPreview((await cookies()).get(PREVIEW_COOKIE)?.value)?.storeId === store.id;
  const page = await getStorefrontPage(store.id, "home", preview);
  return <Sections sections={page?.sections ?? []} store={store} />;
}
