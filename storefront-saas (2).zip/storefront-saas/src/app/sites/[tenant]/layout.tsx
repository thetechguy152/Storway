import { notFound } from "next/navigation";
import { cookies } from "next/headers";
import type { ReactNode } from "react";
import { resolveTenant } from "@/modules/tenancy/host";
import { getStorefrontTheme } from "@/modules/theme/storefront";
import { PREVIEW_COOKIE, verifyPreview } from "@/modules/theme/preview";
import { ThemeFrame } from "@/themes/ThemeFrame";

export const dynamic = "force-dynamic";

export default async function TenantLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ tenant: string }>;
}) {
  const store = await resolveTenant(decodeURIComponent((await params).tenant));
  if (!store) notFound();

  // Draft is shown only with a valid preview cookie signed for THIS store.
  const verified = verifyPreview((await cookies()).get(PREVIEW_COOKIE)?.value);
  const preview = verified?.storeId === store.id;
  const theme = await getStorefrontTheme(store.id, preview);

  return (
    <ThemeFrame store={store} baseThemeId={theme.baseThemeId} tokens={theme.tokens} showPreviewBar={preview}>
      {children}
    </ThemeFrame>
  );
}
