import Link from "next/link";

export default function Home() {
  return (
    <main style={{ maxWidth: 640, margin: "80px auto", fontFamily: "system-ui", padding: 24 }}>
      <h1>Storefront Platform</h1>
      <p>Independent stores. One platform.</p>
      <Link href="/login">Sign in</Link>
    </main>
  );
}
