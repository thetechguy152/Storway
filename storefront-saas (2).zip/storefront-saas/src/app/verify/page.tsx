"use client";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";

function Verify() {
  const token = useSearchParams().get("token");
  const [msg, setMsg] = useState<string | null>(null);

  async function confirm() {
    const res = await fetch("/api/v1/auth/verify", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token }),
    });
    setMsg(res.ok ? "Email verified. You can sign in." : (await res.json()).error?.message);
  }

  return (
    <main style={{ maxWidth: 420, margin: "80px auto", fontFamily: "system-ui", padding: 24 }}>
      <h1>Verify your email</h1>
      {/* Explicit click: link scanners that prefetch URLs must not consume the token. */}
      <button onClick={confirm} disabled={!token}>Confirm email</button>
      {msg && <p>{msg}</p>}
    </main>
  );
}

export default function Page() {
  return <Suspense><Verify /></Suspense>;
}
