import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { SESSION_COOKIE } from "@/modules/auth/session";
import { getSessionUser } from "@/modules/auth/service";
import { listStoresForUser } from "@/modules/tenancy/service";
import { env } from "@/config/env";

export const dynamic = "force-dynamic";

export default async function Admin() {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  const user = token ? await getSessionUser(token) : null;
  if (!user) redirect("/login");

  const stores = await listStoresForUser(user.id);
  const root = env().ROOT_DOMAIN;

  return (
    <main style={{ maxWidth: 720, margin: "40px auto", fontFamily: "system-ui", padding: 24 }}>
      <h1>Your stores</h1>
      {stores.length === 0 && <p>No stores yet. POST /api/v1/stores to create one.</p>}
      <ul>
        {stores.map((s) => (
          <li key={s.id}>
            {s.name} — <a href={`http://${s.slug}.${root}`}>{s.slug}.{root}</a>
            {" · "}
            <a href={`/admin/stores/${s.id}/editor`}>Edit storefront</a>
          </li>
        ))}
      </ul>
    </main>
  );
}
