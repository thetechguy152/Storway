import { notFound, redirect } from "next/navigation";
import { prisma } from "@/server/db";
import { getCookieUser } from "@/modules/auth/session";
import { buildStoreContext } from "@/modules/tenancy/context";
import { getStorefrontPage, getStorefrontTheme } from "@/modules/theme/storefront";
import { pageSlugSchema } from "@/themes/schema";
import { ThemeFrame } from "@/themes/ThemeFrame";
import { Sections } from "@/themes/Sections";
import { CanvasGuard } from "@/editor/CanvasGuard";

export const dynamic = "force-dynamic";

/**
 * The editor's preview iframe: renders the DRAFT with the exact storefront
 * components. Lives on the admin host so the normal session cookie authorizes it.
 */
export default async function Canvas({ params }: { params: Promise<{ storeId: string; slug: string }> }) {
  const { storeId, slug } = await params;
  const user = await getCookieUser();
  if (!user) redirect("/login");

  const ctx = await buildStoreContext(user.id, storeId).catch(() => null);
  const parsedSlug = pageSlugSchema.safeParse(slug);
  if (!ctx || !ctx.can("theme:read") || !parsedSlug.success) notFound();

  const store = await prisma.store.findUniqueOrThrow({
    where: { id: storeId },
    select: { id: true, name: true, slug: true, currency: true },
  });
  const [theme, page] = await Promise.all([
    getStorefrontTheme(storeId, true),
    getStorefrontPage(storeId, parsedSlug.data, true),
  ]);
  if (!page) notFound();

  return (
    <ThemeFrame store={store} baseThemeId={theme.baseThemeId} tokens={theme.tokens} showPreviewBar={false}>
      <CanvasGuard />
      <Sections sections={page.sections} store={store} />
    </ThemeFrame>
  );
}
