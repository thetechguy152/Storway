import { cookies } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@/server/db";
import { SESSION_COOKIE } from "@/modules/auth/session";
import { getSessionUser } from "@/modules/auth/service";
import { hasPermission } from "@/modules/tenancy/rbac";
import { EditorApp } from "@/editor/EditorApp";

export const dynamic = "force-dynamic";
export const metadata = { title: "Storefront editor" };

export default async function EditorPage({ params }: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await params;
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  const user = token ? await getSessionUser(token) : null;
  if (!user) redirect("/login");

  const m = await prisma.membership.findUnique({
    where: { userId_storeId: { userId: user.id, storeId } },
    include: {
      role: true,
      store: { select: { id: true, name: true, slug: true, currency: true, status: true } },
    },
  });
  // Same rule as the API: active member of an active store with theme:write.
  if (!m || m.status !== "ACTIVE" || m.store.status !== "ACTIVE") notFound();
  if (!hasPermission(m.role.permissions, "theme:write")) notFound();

  const { status: _status, ...store } = m.store; // eslint-disable-line @typescript-eslint/no-unused-vars
  return <EditorApp store={store} />;
}
