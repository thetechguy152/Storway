"use client";
import { useState, type ReactNode } from "react";
import { FONTS, type FontKey, type Section, type ThemeTokens } from "@/themes/schema";
import { mediaUrl } from "@/themes/sectionViews";
import type { Asset } from "./api";
import { MediaPicker } from "./MediaPicker";

export type Catalog = {
  baseThemes: { id: string; name: string; description: string; defaultTokens: ThemeTokens }[];
  presets: { id: string; name: string; industry: string }[];
  starters: { id: string; name: string; slug: string; title: string; sections: Section[] }[];
};

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="fld">
      <span>{label}</span>
      {children}
    </label>
  );
}

// ───────── Section inspector ─────────
type SectionProps = {
  storeId: string;
  section: Section;
  assets: Asset[];
  onAssetUploaded: (a: Asset) => void;
  onChange: (patch: Record<string, unknown>) => void;
};

export function SectionInspector({ storeId, section, assets, onAssetUploaded, onChange }: SectionProps) {
  const [picking, setPicking] = useState(false);
  const opt = (v: string) => v || undefined;

  const imageField = (imageId: string | undefined) => (
    <div className="fld">
      <span>Image</span>
      {imageId && (
        // eslint-disable-next-line @next/next/no-img-element
        <img className="thumb" src={mediaUrl(imageId)} alt="" />
      )}
      <div className="row">
        <button type="button" onClick={() => setPicking(true)}>{imageId ? "Change" : "Choose image"}</button>
        {imageId && <button type="button" onClick={() => onChange({ imageId: undefined })}>Remove</button>}
      </div>
    </div>
  );

  let body: ReactNode = null;
  switch (section.type) {
    case "hero": {
      const s = section.settings;
      body = (
        <>
          <Field label="Heading"><input value={s.heading} maxLength={120} onChange={(e) => onChange({ heading: e.target.value })} /></Field>
          <Field label="Subheading"><textarea rows={2} value={s.subheading ?? ""} maxLength={300} onChange={(e) => onChange({ subheading: opt(e.target.value) })} /></Field>
          <Field label="Button text"><input value={s.ctaLabel ?? ""} maxLength={40} onChange={(e) => onChange({ ctaLabel: opt(e.target.value) })} /></Field>
          <Field label="Button link (/path or https://)"><input value={s.ctaHref ?? ""} onChange={(e) => onChange({ ctaHref: opt(e.target.value) })} /></Field>
          <Field label="Alignment">
            <select value={s.align} onChange={(e) => onChange({ align: e.target.value })}>
              <option value="center">Center</option>
              <option value="left">Left</option>
            </select>
          </Field>
          {imageField(s.imageId)}
        </>
      );
      break;
    }
    case "productGrid": {
      const s = section.settings;
      body = (
        <>
          <Field label="Title"><input value={s.title ?? ""} maxLength={120} onChange={(e) => onChange({ title: opt(e.target.value) })} /></Field>
          <Field label={`Products shown (${s.limit})`}>
            <input type="range" min={1} max={24} value={s.limit} onChange={(e) => onChange({ limit: Number(e.target.value) })} />
          </Field>
          <p className="muted">Shows your published products, newest first.</p>
        </>
      );
      break;
    }
    case "richText": {
      const s = section.settings;
      body = (
        <>
          <Field label="Heading"><input value={s.heading ?? ""} maxLength={120} onChange={(e) => onChange({ heading: opt(e.target.value) })} /></Field>
          <Field label="Text (blank line = new paragraph)"><textarea rows={8} value={s.body} maxLength={5000} onChange={(e) => onChange({ body: e.target.value })} /></Field>
        </>
      );
      break;
    }
    case "imageText": {
      const s = section.settings;
      body = (
        <>
          <Field label="Heading"><input value={s.heading ?? ""} maxLength={120} onChange={(e) => onChange({ heading: opt(e.target.value) })} /></Field>
          <Field label="Text"><textarea rows={5} value={s.body} maxLength={2000} onChange={(e) => onChange({ body: e.target.value })} /></Field>
          {imageField(s.imageId)}
          <Field label="Image description (alt text)"><input value={s.imageAlt} maxLength={200} onChange={(e) => onChange({ imageAlt: e.target.value })} /></Field>
          <Field label="Image position">
            <select value={s.imagePosition} onChange={(e) => onChange({ imagePosition: e.target.value })}>
              <option value="right">Right</option>
              <option value="left">Left</option>
            </select>
          </Field>
        </>
      );
      break;
    }
  }

  return (
    <div className="insp">
      {body}
      {picking && (
        <MediaPicker
          storeId={storeId}
          assets={assets}
          onUploaded={onAssetUploaded}
          onPick={(id) => {
            onChange({ imageId: id });
            setPicking(false);
          }}
          onClose={() => setPicking(false)}
        />
      )}
    </div>
  );
}

// ───────── Theme inspector ─────────
type ThemeProps = {
  baseThemeId: string;
  tokens: ThemeTokens;
  catalog: Catalog;
  onBase: (id: string) => void;
  onTokens: (t: ThemeTokens) => void;
  onResetTokens: () => void;
  onPreset: (id: string) => void;
};

const COLOR_LABELS: Record<keyof ThemeTokens["colors"], string> = {
  primary: "Primary",
  background: "Background",
  text: "Text",
  accent: "Accent",
};

export function ThemeInspector({ baseThemeId, tokens, catalog, onBase, onTokens, onResetTokens, onPreset }: ThemeProps) {
  const [preset, setPreset] = useState("");
  const base = catalog.baseThemes.find((t) => t.id === baseThemeId);

  return (
    <div className="insp">
      <Field label="Base theme">
        <select value={baseThemeId} onChange={(e) => onBase(e.target.value)}>
          {catalog.baseThemes.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
      </Field>
      {base && <p className="muted">{base.description}</p>}
      <button type="button" onClick={onResetTokens}>Reset colors &amp; fonts to theme defaults</button>

      <h4>Colors</h4>
      {(Object.keys(COLOR_LABELS) as (keyof ThemeTokens["colors"])[]).map((k) => (
        <Field key={k} label={COLOR_LABELS[k]}>
          <input type="color" value={tokens.colors[k]} onChange={(e) => onTokens({ ...tokens, colors: { ...tokens.colors, [k]: e.target.value } })} />
        </Field>
      ))}

      <h4>Typography</h4>
      {(["heading", "body"] as const).map((k) => (
        <Field key={k} label={k === "heading" ? "Heading font" : "Body font"}>
          <select value={tokens.fonts[k]} onChange={(e) => onTokens({ ...tokens, fonts: { ...tokens.fonts, [k]: e.target.value as FontKey } })}>
            {(Object.keys(FONTS) as FontKey[]).map((f) => <option key={f} value={f}>{FONTS[f].label}</option>)}
          </select>
        </Field>
      ))}

      <Field label="Corner radius">
        <select value={tokens.radius} onChange={(e) => onTokens({ ...tokens, radius: e.target.value as ThemeTokens["radius"] })}>
          <option value="none">Square</option>
          <option value="sm">Slight</option>
          <option value="md">Rounded</option>
          <option value="lg">Very rounded</option>
        </select>
      </Field>

      <h4>Start from an industry preset</h4>
      <p className="muted">Replaces your draft theme and Home page. You can change everything afterwards.</p>
      <div className="row">
        <select value={preset} onChange={(e) => setPreset(e.target.value)}>
          <option value="">Choose…</option>
          {catalog.presets.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <button type="button" disabled={!preset} onClick={() => onPreset(preset)}>Apply</button>
      </div>
    </div>
  );
}
