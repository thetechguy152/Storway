"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import "./editor.css";
import { api, type Asset } from "./api";
import { Canvas, type Device } from "./Canvas";
import { SectionList } from "./SectionList";
import { SectionInspector, ThemeInspector, type Catalog } from "./Inspector";
import { newSection } from "@/themes/defaults";
import {
  pageSlugSchema,
  sectionsSchema,
  tokensSchema,
  type Section,
  type SectionType,
  type ThemeTokens,
} from "@/themes/schema";
import type { ProductCard, StoreInfo } from "@/themes/sectionViews";

type ThemeState = {
  draft: { baseThemeId: string; presetId: string | null; tokens: unknown };
  pages: { slug: string; title: string; isPublished: boolean }[];
};
type PageDto = { slug: string; title: string; sections: unknown };
type Revision = { id: string; createdAt: string };

const uid = () => Math.random().toString(36).slice(2, 10);
const FALLBACK_TOKENS: ThemeTokens = {
  colors: { primary: "#1f3a5f", background: "#ffffff", text: "#1a1a1a", accent: "#b8860b" },
  fonts: { heading: "serif", body: "system" },
  radius: "sm",
};
const SAMPLE_PRODUCTS: ProductCard[] = [1, 2, 3, 4].map((n) => ({
  id: `sample-${n}`,
  title: `Sample product ${n}`,
  slug: `sample-${n}`,
  variants: [{ priceMinor: 1990 + n * 500, currency: "USD" }],
}));

export function EditorApp({ store }: { store: StoreInfo }) {
  const storeId = store.id;

  const [loaded, setLoaded] = useState(false);
  const [baseThemeId, setBaseThemeId] = useState("classic");
  const [tokens, setTokens] = useState<ThemeTokens>(FALLBACK_TOKENS);
  const [pageList, setPageList] = useState<ThemeState["pages"]>([]);
  const [slug, setSlug] = useState("home");
  const [title, setTitle] = useState("Home");
  const [sections, setSections] = useState<Section[]>([]);
  const [catalog, setCatalog] = useState<Catalog>({ baseThemes: [], presets: [], starters: [] });
  const [assets, setAssets] = useState<Asset[]>([]);
  const [products, setProducts] = useState<ProductCard[]>([]);

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [tab, setTab] = useState<"section" | "theme">("section");
  const [device, setDevice] = useState<Device>("desktop");
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<{ text: string; bad?: boolean } | null>(null);
  const [revisions, setRevisions] = useState<Revision[] | null>(null);

  const flash = (text: string, bad = false) => {
    setToast({ text, bad });
    setTimeout(() => setToast(null), 4000);
  };

  // ───────── load ─────────
  const load = useCallback(
    async (pageSlug = "home") => {
      const [theme, cat, media, prods] = await Promise.all([
        api<ThemeState>(`/stores/${storeId}/theme`),
        api<Catalog>("/themes"),
        api<Asset[]>(`/stores/${storeId}/media`).catch(() => [] as Asset[]),
        api<ProductCard[]>(`/stores/${storeId}/products?status=PUBLISHED&limit=24`).catch(() => [] as ProductCard[]),
      ]);
      const parsedTokens = tokensSchema.safeParse(theme.draft.tokens);
      setBaseThemeId(theme.draft.baseThemeId);
      setTokens(parsedTokens.success ? parsedTokens.data : FALLBACK_TOKENS);
      setPageList(theme.pages);
      setCatalog(cat);
      setAssets(media);
      setProducts(prods);

      const page = await api<PageDto>(`/stores/${storeId}/pages/${pageSlug}`);
      const parsed = sectionsSchema.safeParse(page.sections);
      setSlug(page.slug);
      setTitle(page.title);
      setSections(parsed.success ? parsed.data : []);
      setSelectedId(null);
      setDirty(false);
      setLoaded(true);
    },
    [storeId]
  );

  useEffect(() => {
    load().catch((e) => flash(e.message, true));
  }, [load]);

  // ───────── validation (same zod schemas as the server) ─────────
  const errors = useMemo(() => {
    const out: string[] = [];
    const t = tokensSchema.safeParse(tokens);
    if (!t.success) out.push(...t.error.issues.map((i) => `Theme: ${i.message}`));
    const s = sectionsSchema.safeParse(sections);
    if (!s.success)
      out.push(
        ...s.error.issues.map((i) => {
          const idx = typeof i.path[0] === "number" ? `Section ${i.path[0] + 1}` : "Page";
          return `${idx} ${i.path.slice(2).join(".")}: ${i.message}`;
        })
      );
    return out;
  }, [tokens, sections]);

  // ───────── edit helpers ─────────
  const edit = (fn: (s: Section[]) => Section[]) => {
    setSections(fn);
    setDirty(true);
  };
  const selected = sections.find((s) => s.id === selectedId) ?? null;

  const move = (from: number, to: number) =>
    edit((s) => {
      const next = [...s];
      const [item] = next.splice(from, 1);
      if (item) next.splice(Math.min(to, next.length), 0, item);
      return next;
    });
  const add = (type: SectionType, index: number) => {
    const section = newSection(type, uid());
    edit((s) => [...s.slice(0, index), section, ...s.slice(index)]);
    setSelectedId(section.id);
    setTab("section");
  };
  const remove = (id: string) => {
    edit((s) => s.filter((x) => x.id !== id));
    if (selectedId === id) setSelectedId(null);
  };
  const duplicate = (id: string) =>
    edit((s) => {
      const i = s.findIndex((x) => x.id === id);
      if (i < 0) return s;
      const copy = structuredClone(s[i]!);
      copy.id = uid();
      return [...s.slice(0, i + 1), copy, ...s.slice(i + 1)];
    });
  const patchSettings = (id: string, patch: Record<string, unknown>) =>
    edit((s) => s.map((x) => (x.id === id ? ({ ...x, settings: { ...x.settings, ...patch } } as Section) : x)));

  // ───────── actions ─────────
  const save = async (): Promise<boolean> => {
    if (errors.length) {
      flash("Fix the highlighted problems first", true);
      return false;
    }
    setBusy("Saving…");
    try {
      await api(`/stores/${storeId}/theme`, { method: "PUT", json: { baseThemeId, tokens } });
      await api(`/stores/${storeId}/pages/${slug}`, { method: "PUT", json: { title, sections } });
      setDirty(false);
      flash("Draft saved");
      return true;
    } catch (e) {
      flash(e instanceof Error ? e.message : "Save failed", true);
      return false;
    } finally {
      setBusy(null);
    }
  };

  const publish = async () => {
    if (!(await save())) return;
    setBusy("Publishing…");
    try {
      await api(`/stores/${storeId}/theme/publish`, { method: "POST" });
      flash("Published. Your storefront is live with these changes.");
    } catch (e) {
      flash(e instanceof Error ? e.message : "Publish failed", true);
    } finally {
      setBusy(null);
    }
  };

  const openPreview = async () => {
    const win = window.open("", "_blank"); // open synchronously so popup blockers allow it
    if (!(await save())) return win?.close();
    try {
      const { url } = await api<{ url: string }>(`/stores/${storeId}/theme/preview`, { method: "POST" });
      if (win) win.location.href = url;
    } catch (e) {
      win?.close();
      flash(e instanceof Error ? e.message : "Could not open preview", true);
    }
  };

  const confirmDiscard = () => !dirty || window.confirm("You have unsaved changes. Discard them?");

  const switchPage = async (next: string) => {
    if (next === slug || !confirmDiscard()) return;
    try {
      await load(next);
    } catch (e) {
      flash(e instanceof Error ? e.message : "Could not load page", true);
    }
  };

  const createFromStarter = async (starterId: string) => {
    const starter = catalog.starters.find((s) => s.id === starterId);
    if (!starter || !confirmDiscard()) return;
    const wanted = window.prompt("Page address (letters, numbers, hyphens)", starter.slug);
    if (!wanted) return;
    const parsed = pageSlugSchema.safeParse(wanted);
    if (!parsed.success) return flash("Invalid page address", true);
    if (pageList.some((p) => p.slug === parsed.data)) return flash("A page with that address already exists", true);
    try {
      await api(`/stores/${storeId}/pages/${parsed.data}`, { method: "PUT", json: { title: starter.title, sections: starter.sections } });
      await load(parsed.data);
      flash(`Created /pages/${parsed.data}`);
    } catch (e) {
      flash(e instanceof Error ? e.message : "Could not create page", true);
    }
  };

  const applyPreset = async (presetId: string) => {
    if (!window.confirm("Replace your draft theme and Home page with this preset? Unsaved changes are lost.")) return;
    try {
      await api(`/stores/${storeId}/theme/preset`, { method: "POST", json: { presetId } });
      await load("home");
      flash("Preset applied to your draft");
    } catch (e) {
      flash(e instanceof Error ? e.message : "Could not apply preset", true);
    }
  };

  const loadRevisions = async () => {
    try {
      setRevisions(await api<Revision[]>(`/stores/${storeId}/theme/revisions`));
    } catch (e) {
      flash(e instanceof Error ? e.message : "Could not load history", true);
    }
  };

  const restore = async (id: string) => {
    if (!window.confirm("Load this version into your draft? Unsaved changes are lost. It goes live only when you publish.")) return;
    try {
      await api(`/stores/${storeId}/theme/revisions/${id}/restore`, { method: "POST" });
      setRevisions(null);
      await load(slug);
      flash("Version loaded into your draft");
    } catch (e) {
      flash(e instanceof Error ? e.message : "Restore failed", true);
    }
  };

  // Ctrl/Cmd+S and unsaved-changes guard.
  const saveRef = useRef(save);
  saveRef.current = save;
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        void saveRef.current();
      }
    };
    const onUnload = (e: BeforeUnloadEvent) => {
      if (dirty) e.preventDefault();
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("beforeunload", onUnload);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("beforeunload", onUnload);
    };
  }, [dirty]);

  if (!loaded) return <div className="ed-loading">{toast?.bad ? toast.text : "Loading editor…"}</div>;

  const baseDefaults = catalog.baseThemes.find((t) => t.id === baseThemeId)?.defaultTokens;

  return (
    <div className="ed">
      <header className="ed-top">
        <a href="/admin" className="ed-back">← Stores</a>
        <strong className="ed-store">{store.name}</strong>

        <select value={slug} onChange={(e) => switchPage(e.target.value)} aria-label="Page">
          {pageList.map((p) => <option key={p.slug} value={p.slug}>{p.slug === "home" ? "Home" : p.title} (/{p.slug === "home" ? "" : `pages/${p.slug}`})</option>)}
        </select>
        <select value="" onChange={(e) => e.target.value && createFromStarter(e.target.value)} aria-label="New page">
          <option value="">+ New page…</option>
          {catalog.starters.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
        <input
          className="ed-title"
          value={title}
          maxLength={120}
          aria-label="Page title"
          onChange={(e) => {
            setTitle(e.target.value);
            setDirty(true);
          }}
        />

        <div className="ed-devices" role="group" aria-label="Preview size">
          {(["desktop", "tablet", "mobile"] as Device[]).map((d) => (
            <button key={d} type="button" className={d === device ? "on" : ""} onClick={() => setDevice(d)}>
              {d[0]!.toUpperCase() + d.slice(1)}
            </button>
          ))}
        </div>

        <span className="ed-status">{busy ?? (dirty ? "Unsaved changes" : "All changes saved")}</span>

        <div className="ed-hist">
          <button type="button" onClick={() => (revisions ? setRevisions(null) : loadRevisions())}>History</button>
          {revisions && (
            <div className="ed-pop">
              {revisions.length === 0 && <p className="muted">No published versions yet.</p>}
              {revisions.map((r) => (
                <div key={r.id} className="row">
                  <span>{new Date(r.createdAt).toLocaleString()}</span>
                  <button type="button" onClick={() => restore(r.id)}>Load</button>
                </div>
              ))}
            </div>
          )}
        </div>
        <button type="button" onClick={openPreview} disabled={!!busy}>Preview</button>
        <button type="button" onClick={save} disabled={!!busy || !dirty}>Save draft</button>
        <button type="button" className="primary" onClick={publish} disabled={!!busy}>Publish</button>
      </header>

      <aside className="ed-left">
        <SectionList
          sections={sections}
          selectedId={selectedId}
          onSelect={(id) => {
            setSelectedId(id);
            setTab("section");
          }}
          onMove={move}
          onAdd={add}
          onRemove={remove}
          onDuplicate={duplicate}
        />
      </aside>

      <main className="ed-center">
        <Canvas
          store={store}
          baseThemeId={baseThemeId}
          tokens={tokens}
          sections={sections}
          products={products.length ? products : SAMPLE_PRODUCTS}
          device={device}
          selectedId={selectedId}
          onSelect={(id) => {
            setSelectedId(id);
            setTab("section");
          }}
        />
      </main>

      <aside className="ed-right">
        <div className="ed-tabs">
          <button type="button" className={tab === "section" ? "on" : ""} onClick={() => setTab("section")}>Section</button>
          <button type="button" className={tab === "theme" ? "on" : ""} onClick={() => setTab("theme")}>Theme</button>
        </div>

        {errors.length > 0 && (
          <ul className="ed-errors" role="alert">
            {errors.map((e, i) => <li key={i}>{e}</li>)}
          </ul>
        )}

        {tab === "section" &&
          (selected ? (
            <SectionInspector
              key={selected.id}
              storeId={storeId}
              section={selected}
              assets={assets}
              onAssetUploaded={(a) => setAssets((prev) => [a, ...prev])}
              onChange={(patch) => patchSettings(selected.id, patch)}
            />
          ) : (
            <p className="muted pad">Select a section in the list or on the canvas to edit it.</p>
          ))}

        {tab === "theme" && (
          <ThemeInspector
            baseThemeId={baseThemeId}
            tokens={tokens}
            catalog={catalog}
            onBase={(id) => {
              setBaseThemeId(id);
              setDirty(true);
            }}
            onTokens={(t) => {
              setTokens(t);
              setDirty(true);
            }}
            onResetTokens={() => {
              if (baseDefaults) {
                setTokens(baseDefaults);
                setDirty(true);
              }
            }}
            onPreset={applyPreset}
          />
        )}
      </aside>

      {toast && <div className={`ed-toast${toast.bad ? " bad" : ""}`} role="status">{toast.text}</div>}
    </div>
  );
}
