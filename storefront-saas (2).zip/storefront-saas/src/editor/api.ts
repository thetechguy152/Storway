export type Asset = { id: string; url: string; filename: string; mime: string; sizeBytes: number; createdAt: string };

type Init = { method?: string; json?: unknown; body?: BodyInit };

/** Thin client for our own /api/v1. Throws Error(message) using the standard error envelope. */
export async function api<T = unknown>(path: string, init: Init = {}): Promise<T> {
  const res = await fetch(`/api/v1${path}`, {
    method: init.method ?? "GET",
    headers: init.json !== undefined ? { "content-type": "application/json" } : undefined,
    body: init.json !== undefined ? JSON.stringify(init.json) : init.body,
  });
  const body = await res.json().catch(() => null);
  if (!res.ok) {
    const fields = body?.error?.fieldErrors as Record<string, string[]> | undefined;
    const detail = fields ? Object.entries(fields).map(([k, v]) => `${k}: ${v.join(", ")}`).join("; ") : "";
    throw new Error([body?.error?.message ?? "Request failed", detail].filter(Boolean).join(" - "));
  }
  return body.data as T;
}
