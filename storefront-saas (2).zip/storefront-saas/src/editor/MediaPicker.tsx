"use client";
import { useState, type ChangeEvent } from "react";
import { api, type Asset } from "./api";

type Props = {
  storeId: string;
  assets: Asset[];
  onUploaded: (a: Asset) => void;
  onPick: (id: string) => void;
  onClose: () => void;
};

export function MediaPicker({ storeId, assets, onUploaded, onPick, onClose }: Props) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function upload(e: ChangeEvent<HTMLInputElement>) {
    const input = e.target;
    const file = input.files?.[0];
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const asset = await api<Asset>(`/stores/${storeId}/media`, { method: "POST", body: fd });
      onUploaded(asset);
      onPick(asset.id);
    } catch (ex) {
      setError(ex instanceof Error ? ex.message : "Upload failed");
    } finally {
      setBusy(false);
      input.value = "";
    }
  }

  return (
    <div className="mp-back" onClick={onClose}>
      <div className="mp" role="dialog" aria-label="Media library" onClick={(e) => e.stopPropagation()}>
        <div className="mp-head">
          <strong>Media library</strong>
          <button type="button" onClick={onClose}>Close</button>
        </div>
        <label className="mp-upload">
          {busy ? "Uploading…" : "Upload image (PNG, JPEG, GIF, WebP)"}
          <input type="file" accept="image/png,image/jpeg,image/gif,image/webp" onChange={upload} disabled={busy} hidden />
        </label>
        {error && <p className="err">{error}</p>}
        <div className="mp-grid">
          {assets.length === 0 && <p className="muted">No images yet.</p>}
          {assets.map((a) => (
            <button key={a.id} type="button" className="mp-item" onClick={() => onPick(a.id)} title={a.filename}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={a.url} alt={a.filename} loading="lazy" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
