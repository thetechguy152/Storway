"use client";
import { useEffect } from "react";

/** Inside the editor iframe, links must not navigate away from the canvas. */
export function CanvasGuard() {
  useEffect(() => {
    const block = (e: MouseEvent) => {
      if ((e.target as HTMLElement | null)?.closest("a")) e.preventDefault();
    };
    document.addEventListener("click", block, true);
    return () => document.removeEventListener("click", block, true);
  }, []);
  return null;
}
