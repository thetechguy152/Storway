"use client";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import { getThemeImpl, tokenVars } from "@/themes/registry";
import { FontLinks } from "@/themes/FontLinks";
import { FONT_STACKS, type Section, type ThemeTokens } from "@/themes/schema";
import { SectionView, type ProductCard, type StoreInfo } from "@/themes/sectionViews";

export type Device = "desktop" | "tablet" | "mobile";
export const DEVICE_WIDTH: Record<Device, number> = { desktop: 1200, tablet: 768, mobile: 390 };

type Props = {
  store: StoreInfo;
  baseThemeId: string;
  tokens: ThemeTokens;
  sections: Section[];
  products: ProductCard[];
  device: Device;
  selectedId: string | null;
  onSelect: (id: string) => void;
};

/**
 * Live canvas. Renders the SAME theme layout and section components the real
 * storefront uses, so what you see is what ships. The device frame is a fixed
 * width scaled down (CSS zoom) to fit the available space; sections adapt via
 * container-relative units, so tablet/mobile widths reflow like a real screen.
 */
export function Canvas({ store, baseThemeId, tokens, sections, products, device, selectedId, onSelect }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [avail, setAvail] = useState(1000);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setAvail(el.clientWidth - 32));
    ro.observe(el);
    setAvail(el.clientWidth - 32);
    return () => ro.disconnect();
  }, []);

  const width = DEVICE_WIDTH[device];
  const zoom = Math.min(1, Math.max(0.2, avail / width));
  const { Layout } = getThemeImpl(baseThemeId);

  return (
    <div className="cv-wrap" ref={wrapRef}>
      <div
        className={`cv-frame cv-${device}`}
        style={{ width, zoom } as CSSProperties}
        // Links inside the canvas must not navigate away from the editor.
        onClickCapture={(e) => {
          if ((e.target as HTMLElement).closest("a")) e.preventDefault();
        }}
      >
        <FontLinks tokens={tokens} />
        <div
          style={{
            ...tokenVars(tokens),
            background: "var(--color-background)",
            color: "var(--color-text)",
            fontFamily: FONT_STACKS[tokens.fonts.body],
            minHeight: 600,
            containerType: "inline-size",
          } as CSSProperties}
        >
          <Layout store={store} preview={false}>
            {sections.length === 0 && <p className="cv-empty">This page is empty. Add a section on the left.</p>}
            {sections.map((s) => (
              <div
                key={s.id}
                className={`cv-sec${s.id === selectedId ? " on" : ""}`}
                onClick={() => onSelect(s.id)}
              >
                <SectionView section={s} products={products} />
              </div>
            ))}
          </Layout>
        </div>
      </div>
    </div>
  );
}
