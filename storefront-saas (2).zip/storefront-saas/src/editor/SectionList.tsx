"use client";
import { useState, type DragEvent } from "react";
import { SECTION_TYPES } from "@/themes/defaults";
import type { Section, SectionType } from "@/themes/schema";

const TYPE_MIME = "application/x-section-type";
const label = (t: SectionType) => SECTION_TYPES.find((x) => x.type === t)?.label ?? t;

function summary(s: Section): string {
  switch (s.type) {
    case "hero": return s.settings.heading;
    case "productGrid": return s.settings.title ?? "Products";
    case "richText": return s.settings.heading ?? s.settings.body.slice(0, 30);
    case "imageText": return s.settings.heading ?? s.settings.body.slice(0, 30);
  }
}

type Props = {
  sections: Section[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onMove: (from: number, to: number) => void;
  onAdd: (type: SectionType, index: number) => void;
  onRemove: (id: string) => void;
  onDuplicate: (id: string) => void;
};

/**
 * Native HTML5 drag-and-drop (no dependency): drag rows to reorder, or drag a
 * block from the palette into the list. Every row also has Up/Down buttons so
 * reordering works with keyboard and touch.
 */
export function SectionList({ sections, selectedId, onSelect, onMove, onAdd, onRemove, onDuplicate }: Props) {
  const [dragFrom, setDragFrom] = useState<number | null>(null);
  const [over, setOver] = useState<number | null>(null);

  const drop = (e: DragEvent, index: number) => {
    e.preventDefault();
    e.stopPropagation();
    const newType = e.dataTransfer.getData(TYPE_MIME) as SectionType | "";
    if (newType) onAdd(newType, index);
    else if (dragFrom !== null && dragFrom !== index) onMove(dragFrom, index);
    setDragFrom(null);
    setOver(null);
  };

  return (
    <div className="sl">
      <h3>Add section</h3>
      <div className="sl-palette">
        {SECTION_TYPES.map((t) => (
          <button
            key={t.type}
            type="button"
            className="sl-chip"
            draggable
            title={`${t.hint} (click or drag into the list)`}
            onDragStart={(e) => {
              e.dataTransfer.setData(TYPE_MIME, t.type);
              e.dataTransfer.effectAllowed = "copy";
            }}
            onClick={() => onAdd(t.type, sections.length)}
          >
            + {t.label}
          </button>
        ))}
      </div>

      <h3>Page sections</h3>
      <ul
        className="sl-list"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => drop(e, sections.length)}
      >
        {sections.length === 0 && <li className="sl-hint">Drag a block here or click one above.</li>}
        {sections.map((s, i) => (
          <li
            key={s.id}
            draggable
            className={`sl-row${s.id === selectedId ? " on" : ""}${over === i ? " over" : ""}${dragFrom === i ? " drag" : ""}`}
            onClick={() => onSelect(s.id)}
            onDragStart={(e) => {
              setDragFrom(i);
              e.dataTransfer.effectAllowed = "move";
            }}
            onDragOver={(e) => {
              e.preventDefault();
              setOver(i);
            }}
            onDragLeave={() => setOver((o) => (o === i ? null : o))}
            onDrop={(e) => drop(e, i)}
            onDragEnd={() => {
              setDragFrom(null);
              setOver(null);
            }}
          >
            <span className="sl-grip" aria-hidden>⋮⋮</span>
            <span className="sl-name">
              <strong>{label(s.type)}</strong>
              <small>{summary(s)}</small>
            </span>
            <span className="sl-actions" onClick={(e) => e.stopPropagation()}>
              <button type="button" aria-label="Move up" disabled={i === 0} onClick={() => onMove(i, i - 1)}>↑</button>
              <button type="button" aria-label="Move down" disabled={i === sections.length - 1} onClick={() => onMove(i, i + 1)}>↓</button>
              <button type="button" aria-label="Duplicate" onClick={() => onDuplicate(s.id)}>⧉</button>
              <button type="button" aria-label="Delete" onClick={() => onRemove(s.id)}>✕</button>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
